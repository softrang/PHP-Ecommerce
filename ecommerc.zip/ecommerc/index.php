<?php
// Include config and controllers
include_once __DIR__ . '/admin/config/database.php';
include_once __DIR__ . '/controllars/databasequery.php';

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Check if database connection details are in the session
if (!isset($_SESSION['db_details'])) {
    //echo "<p>No database connection details found. Please <a href='admin/config/connection.php'>set them here</a>.</p>";
    header("location: admin/config/connection.php");
    exit; // Stop script execution if connection details are missing
}

?>

    <?php include_once __DIR__ . '/views/layouts/frontend/header.php'; ?>
    
    <main>
        <?php //include_once __DIR__ . '/views/layouts/frontend/template/homebigslider.php'; ?>
        <?php //include_once __DIR__ . '/views/layouts/frontend/template/pdiscount.php'; ?>
        <?php //include_once __DIR__ . '/views/layouts/frontend/template/plataset.php'; ?>
        <?php include_once __DIR__ . '/views/layouts/frontend/template/catagory.php'; ?>
        <?php include_once __DIR__ . '/views/layouts/frontend/template/lataset.php'; ?>
        <?php include_once __DIR__ . '/views/layouts/frontend/template/future.php'; ?>
        <?php include_once __DIR__ . '/views/layouts/frontend/template/banar.php'; ?>
        <?php //include_once __DIR__ . '/views/layouts/frontend/template/blog.php'; ?>
       
    </main>
    <?php include_once __DIR__ . '/views/layouts/frontend/fotter.php'; ?>

<?php
$base_url= "ecommerc";  // Set your base URL

 
$admin_url = $base_url ."/admin";
$config_url = $admin_url. "/config";
$admin_page_url= $admin_url ."/pages";
$admin_css_url= $base_url ."/assets/css/admin/admin.css";
$admin_js_url= $base_url ."/assets/css/admin/admin.js";
$controllars_url = $base_url ."/controllars";
$uploads_url =  $base_url ."/uploads";

?>
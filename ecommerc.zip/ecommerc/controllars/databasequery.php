<?php
include_once __DIR__ . '/../admin/config/database.php';


global $conn;
// Load .env variables manually
$env = parse_ini_file(__DIR__.'/../admin/config/.env');

// Fetch variables
$host = $env['DB_HOST'];
$username = $env['DB_USERNAME'];
$password = $env['DB_PASSWORD'];
$dbname = $env['DB_DATABASE'];
$port = $env['DB_PORT'];

$conn = new mysqli($host, $username, $password, $dbname, $port);




// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


// Function to fetch products if the table exists
function getTabile($conn, $tableName) {
    try {
        // Check if the table exists
        $checkTableQuery = "SHOW TABLES LIKE '$tableName'";
        $checkTableResult = $conn->query($checkTableQuery);

        // If table does not exist, return an empty array
        if ($checkTableResult->num_rows === 0) {
            throw new Exception("Table '$tableName' does not exist.");
        }

        // Query to fetch data from the table
        $query = "SELECT * FROM $tableName";
        $result = $conn->query($query);

        // Check if the query was successful
        if ($result === false) {
            throw new Exception("Error fetching data from '$tableName': " . $conn->error);
        }

        // Fetch all rows as an associative array
        return $result->fetch_all(MYSQLI_ASSOC);
    } catch (Exception $e) {
        // Log or display the error message
        echo $e->getMessage();
        return [];
    }
}

?>

-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 22, 2024 at 10:02 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecommerce`
--

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `id` int(11) NOT NULL,
  `brand_name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_german2_ci;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`id`, `brand_name`, `created_at`, `updated_at`) VALUES
(4, 'Guchi', '2024-12-19 07:12:42', '2024-12-19 07:12:42'),
(5, 'Justnock', '2024-12-19 07:12:47', '2024-12-19 07:12:47'),
(6, 'Nicke', '2024-12-19 14:54:48', '2024-12-19 14:54:48'),
(7, 'HP', '2024-12-19 14:54:57', '2024-12-19 14:54:57');

-- --------------------------------------------------------

--
-- Table structure for table `colors`
--

CREATE TABLE `colors` (
  `id` int(11) NOT NULL,
  `color_name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_german2_ci;

--
-- Dumping data for table `colors`
--

INSERT INTO `colors` (`id`, `color_name`, `created_at`, `updated_at`) VALUES
(4, 'Green', '2024-12-19 07:02:47', '2024-12-19 07:02:47'),
(5, 'Red', '2024-12-19 07:04:10', '2024-12-19 07:04:10'),
(6, 'Blue', '2024-12-19 14:54:12', '2024-12-19 14:54:12'),
(7, 'Yellow', '2024-12-19 14:54:12', '2024-12-19 14:54:34');

-- --------------------------------------------------------

--
-- Table structure for table `endcats`
--

CREATE TABLE `endcats` (
  `id` int(11) NOT NULL,
  `endtopcat` varchar(255) NOT NULL,
  `endmidcat` varchar(255) NOT NULL,
  `endcat` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_german2_ci;

--
-- Dumping data for table `endcats`
--

INSERT INTO `endcats` (`id`, `endtopcat`, `endmidcat`, `endcat`, `created_at`, `updated_at`) VALUES
(1, 'Men\'s Fashion', 'Clothing', 'Polo Shirt', '2024-12-17 02:16:13', '2024-12-17 20:18:39'),
(2, 'Men\'s Fashion', 'Clothing', 'T-Shirt', '2024-12-17 02:16:41', '2024-12-17 20:20:22');

-- --------------------------------------------------------

--
-- Table structure for table `header_fotter`
--

CREATE TABLE `header_fotter` (
  `id` int(11) NOT NULL,
  `d_name` varchar(255) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `nl_title` varchar(255) NOT NULL,
  `nl_dic` text NOT NULL,
  `support` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_german2_ci;

--
-- Dumping data for table `header_fotter`
--

INSERT INTO `header_fotter` (`id`, `d_name`, `phone`, `email`, `address`, `nl_title`, `nl_dic`, `support`, `created_at`, `updated_at`) VALUES
(1, 'dailyshop', '++8801000000000', 'info@dailyshop.com', 'Dhak Bangladesh', 'Join Our Newsletter Now', 'Get E-mail updates about our latest shop and special offers.', 'support 24/7 time', '2024-12-21 12:16:04', '2024-12-21 15:33:19');

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `id` int(11) NOT NULL,
  `image_name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `update_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_german2_ci;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`id`, `image_name`, `created_at`, `update_at`) VALUES
(59, '6766cb0e6feae_564564.jpg', '2024-12-18 19:52:27', '2024-12-21 14:05:02'),
(60, '6766cb1d0bc1f_564564.jpg', '2024-12-18 19:52:33', '2024-12-21 14:05:17'),
(62, '6766cb2c9cacd_564564.jpg', '2024-12-18 20:49:24', '2024-12-21 14:05:32'),
(64, '6766cb3e30a41_564564.jpg', '2024-12-18 22:16:51', '2024-12-21 14:05:50');

-- --------------------------------------------------------

--
-- Table structure for table `midcats`
--

CREATE TABLE `midcats` (
  `id` int(11) NOT NULL,
  `midtopcat` varchar(255) NOT NULL,
  `midcat` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_german2_ci;

--
-- Dumping data for table `midcats`
--

INSERT INTO `midcats` (`id`, `midtopcat`, `midcat`, `created_at`, `updated_at`) VALUES
(1, 'Men\'s Fashion', 'Clothing', '2024-12-17 00:59:39', '2024-12-17 19:58:29'),
(2, 'Men\'s Fashion', 'Footware', '2024-12-17 01:04:39', '2024-12-17 20:00:37'),
(3, 'Woman\'s Fashion', 'Clothing', '2024-12-17 01:48:52', '2024-12-17 20:02:02'),
(4, 'Woman\'s Fashion', 'Footare', '2024-12-17 18:29:21', '2024-12-17 20:02:35'),
(5, 'Kid\'s Fashion', 'Clothing', '2024-12-17 20:03:41', '2024-12-17 20:03:41'),
(6, 'Kid\'s Fashion', 'Toy', '2024-12-17 20:03:56', '2024-12-17 20:03:56'),
(7, 'Home and Kitchen', 'Home Decor', '2024-12-17 20:05:02', '2024-12-17 20:05:02'),
(8, 'Home and Kitchen', 'Furniture', '2024-12-17 20:05:19', '2024-12-17 20:05:19'),
(9, 'Custiomized Item', 'Mug', '2024-12-17 20:06:00', '2024-12-17 20:06:00'),
(10, 'Custiomized Item', 'Fabric', '2024-12-17 20:06:24', '2024-12-17 20:06:24');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `total` decimal(10,2) NOT NULL CHECK (`total` >= 0),
  `status` enum('pending','completed','cancelled','refunded') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_german2_ci;

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL CHECK (`quantity` > 0),
  `price` decimal(10,2) NOT NULL CHECK (`price` >= 0),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_german2_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `payment_method_id` int(11) NOT NULL,
  `payment_status` enum('pending','paid','failed','refunded') DEFAULT 'pending',
  `transaction_id` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_german2_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payment_methods`
--

CREATE TABLE `payment_methods` (
  `id` int(11) NOT NULL,
  `method_name` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_german2_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `t_cat` varchar(255) DEFAULT NULL,
  `m_cat` varchar(255) DEFAULT NULL,
  `e_cat` varchar(255) DEFAULT NULL,
  `p_title` varchar(255) DEFAULT NULL,
  `p_price` float DEFAULT NULL,
  `p_discount` float DEFAULT NULL,
  `p_stock` int(11) DEFAULT NULL,
  `p_sizes` varchar(255) DEFAULT NULL,
  `p_colors` varchar(255) DEFAULT NULL,
  `p_brand` varchar(255) DEFAULT NULL,
  `p_is_future` varchar(255) DEFAULT NULL,
  `p_is_lataset` varchar(255) DEFAULT NULL,
  `p_is_discount` varchar(255) DEFAULT NULL,
  `p_s_dis` text DEFAULT NULL,
  `p_dis` text DEFAULT NULL,
  `thumb_image` varchar(255) DEFAULT NULL,
  `future_images` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_german2_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `t_cat`, `m_cat`, `e_cat`, `p_title`, `p_price`, `p_discount`, `p_stock`, `p_sizes`, `p_colors`, `p_brand`, `p_is_future`, `p_is_lataset`, `p_is_discount`, `p_s_dis`, `p_dis`, `thumb_image`, `future_images`, `created_at`, `updated_at`) VALUES
(29, 'Men\'s Fashion', 'Footware', NULL, 'Eye Box125', 200, 100, 50, 'L, XL', 'Red, Blue', 'Nicke', 'Yes', 'No', 'Yes', 'ুিট্যডপচযডপট্', 'টযডটচযডপাযডচটযড', '67661c88c162f_WhatsApp_Image_2024-07-09_at_10.29.00_7e979df4-removebg-preview.png', 'futureimage_67661c88c19ee_1235-removebg-preview.png,futureimage_67661c88c1c89_photo-removebg-preview.png,futureimage_67661c88c1ee2_rangcon logo made oasim.png', '2024-12-20 22:16:29', '2024-12-21 01:40:24'),
(31, 'Men\'s Fashion', 'Clothing', 'Polo Shirt', 'Multifunctional Camara ', 100, 200, 600, 'S, M', 'Green, Red', 'Justnock', 'Yes', 'Yes', 'No', 'ryeryrh', 'reytgruyh', '67663c0a87850_WhatsApp_Image_2024-07-02_at_17.33.27_2cfc5ebc-removebg-preview.png', 'futureimage_67663c0a87c76_WhatsApp_Image_2024-07-09_at_10.29.08_0ea05248-removebg-preview.png,futureimage_67663c0a87f87_WhatsApp_Image_2024-07-09_at_10.28.54_34c67356-removebg-preview.png,futureimage_67663c0a88207_WhatsApp_Image_2024-07-09_at_10.28.59_94f6d15e-removebg-preview.png', '2024-12-21 03:32:33', '2024-12-21 03:54:50'),
(32, 'Woman\'s Fashion', 'Clothing', 'Polo Shirt', 'Multifunctional Camara 1', 500, 600, 100, 'S, M', 'Red', 'Justnock', 'Yes', 'Yes', 'No', 'dfewrfetgdsfwerty', 'ewtgdsfgwersdtg', '6766776ba9ab0_WhatsApp_Image_2024-07-02_at_17.34.53_804ecfad-removebg-preview.png', 'futureimage_6766776ba9dd2_WhatsApp_Image_2024-07-09_at_10.29.52_f8247fca-removebg-preview.png,futureimage_6766776baa075_WhatsApp_Image_2024-07-02_at_17.34.51_5198b22a-removebg-preview.png', '2024-12-21 04:10:31', '2024-12-21 08:08:11'),
(33, 'Woman\'s Fashion', 'Clothing', 'T-Shirt', 'Multifunctional Camara ', 600, 100, 50, 'XL, XXL, M', 'Red, Blue', 'Justnock', 'Yes', 'Yes', 'Yes', 'trujtrygujtruj', 'trujgfhrtrtrtrtfghjk', '67664223b6353_WhatsApp_Image_2024-07-09_at_10.28.59_94f6d15e-removebg-preview.png', 'futureimage_67664223b6609_WhatsApp_Image_2024-07-09_at_10.28.59_94f6d15e-removebg-preview.png,futureimage_67664223b68c9_WhatsApp_Image_2024-07-02_at_17.33.32_e783121b-removebg-preview-removebg-preview.png', '2024-12-21 04:20:51', '2024-12-21 04:20:51'),
(34, 'Kid\'s Fashion', 'Toy', NULL, 'Eye Box', 600, 900, 100, 'M, L', 'Red, Blue', 'Justnock', 'Yes', 'Yes', 'Yes', 'reyturtyeru', 'reuyyrtujrtyhtr', '676648c014f2c_WhatsApp_Image_2024-07-02_at_17.33.32_e783121b-removebg-preview-removebg-preview.png', 'futureimage_676648c01511e_WhatsApp_Image_2024-07-09_at_10.28.59_94f6d15e-removebg-preview.png,futureimage_676648c0153e6_WhatsApp_Image_2024-07-02_at_17.33.32_e783121b-removebg-preview-removebg-preview.png', '2024-12-21 04:49:04', '2024-12-21 04:49:04'),
(35, 'Kid\'s Fashion', 'Clothing', 'T-Shirt', 'Multifunctional Camara ', 600, 600, 500, 'L, XL', 'Red, Blue', 'Justnock', 'Yes', 'Yes', 'Yes', 'dsgretertgfdhgr', 'fdgreyhfdgrehyer', '67664cd18c987_WhatsApp_Image_2024-07-09_at_10.28.59_94f6d15e-removebg-preview.png', 'futureimage_67664cd18cc1a_WhatsApp_Image_2024-07-02_at_17.33.34_4dd46f4a-removebg-preview-removebg-preview.png,futureimage_67664cd18cebe_WhatsApp_Image_2024-07-02_at_17.34.14_58d8b7a6-removebg-preview.png', '2024-12-21 05:06:25', '2024-12-21 05:06:25');

-- --------------------------------------------------------

--
-- Table structure for table `sizes`
--

CREATE TABLE `sizes` (
  `id` int(11) NOT NULL,
  `size_name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_german2_ci;

--
-- Dumping data for table `sizes`
--

INSERT INTO `sizes` (`id`, `size_name`, `created_at`, `updated_at`) VALUES
(4, 'S', '2024-12-19 07:03:40', '2024-12-19 07:04:03'),
(5, 'M', '2024-12-19 07:03:52', '2024-12-19 07:03:52'),
(6, 'L', '2024-12-19 14:53:43', '2024-12-19 14:53:43'),
(8, 'XL', '2024-12-19 14:53:54', '2024-12-19 14:53:54'),
(9, 'XXL', '2024-12-19 14:54:01', '2024-12-19 14:54:01');

-- --------------------------------------------------------

--
-- Table structure for table `social_link`
--

CREATE TABLE `social_link` (
  `id` int(11) NOT NULL,
  `facebook` varchar(255) NOT NULL,
  `instagram` varchar(255) NOT NULL,
  `linkedin` varchar(255) NOT NULL,
  `twiter` varchar(255) NOT NULL,
  `printerest` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_german2_ci;

--
-- Dumping data for table `social_link`
--

INSERT INTO `social_link` (`id`, `facebook`, `instagram`, `linkedin`, `twiter`, `printerest`, `created_at`, `updated_at`) VALUES
(1, 'https://www.facebook.com', 'https://www.instagram.com', 'https://www.linkedin.com', 'https://x.com', 'https://www.pinterest.com', '2024-12-21 15:25:17', '2024-12-21 15:25:17');

-- --------------------------------------------------------

--
-- Table structure for table `topcats`
--

CREATE TABLE `topcats` (
  `id` int(11) NOT NULL,
  `topcat` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_german2_ci;

--
-- Dumping data for table `topcats`
--

INSERT INTO `topcats` (`id`, `topcat`, `created_at`, `updated_at`) VALUES
(1, 'Men\'s Fashion', '2024-12-16 23:43:32', '2024-12-17 19:54:10'),
(2, 'Woman\'s Fashion', '2024-12-16 23:50:37', '2024-12-17 19:54:36'),
(3, 'Kid\'s Fashion', '2024-12-16 23:52:16', '2024-12-17 19:55:43'),
(4, 'Home and Kitchen', '2024-12-17 00:19:16', '2024-12-17 19:56:06'),
(5, 'Custiomized Item', '2024-12-17 00:31:47', '2024-12-17 19:56:46');

-- --------------------------------------------------------

--
-- Table structure for table `uselinks`
--

CREATE TABLE `uselinks` (
  `id` int(11) NOT NULL,
  `use_link` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_german2_ci;

--
-- Dumping data for table `uselinks`
--

INSERT INTO `uselinks` (`id`, `use_link`, `created_at`, `updated_at`) VALUES
(2, 'About  Us', '2024-12-22 03:57:55', '2024-12-22 03:57:55'),
(3, 'About Our Shop', '2024-12-22 03:58:42', '2024-12-22 03:58:42'),
(4, 'Secure Shopping', '2024-12-22 03:59:03', '2024-12-22 03:59:03'),
(5, 'Delibary Information', '2024-12-22 04:00:01', '2024-12-22 04:00:01'),
(6, 'Privacy Policy', '2024-12-22 04:00:24', '2024-12-22 04:00:24'),
(7, 'Our Site Map', '2024-12-22 04:00:34', '2024-12-22 04:00:34'),
(8, 'Who We are', '2024-12-22 04:16:01', '2024-12-22 04:16:01'),
(9, 'Ore Service', '2024-12-22 04:16:10', '2024-12-22 04:16:10'),
(10, 'Project', '2024-12-22 04:16:42', '2024-12-22 04:16:42'),
(11, 'Conctact', '2024-12-22 04:16:53', '2024-12-22 04:16:53'),
(12, 'Inovation', '2024-12-22 04:17:07', '2024-12-22 04:17:07');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `address` text NOT NULL,
  `role` enum('user','admin') DEFAULT 'user',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_german2_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `phone`, `address`, `role`, `created_at`, `updated_at`) VALUES
(4, 'admin', 'admin@example.com', '$2y$10$nql5dKDd01VEqQpUXeiWmOk94kEBPnXoMdOLHo8XrtDDMwCWaa/V2', '+88011111111111', 'Dhaka Bangladesh', '', '2024-12-22 06:26:34', '2024-12-22 06:26:34');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `colors`
--
ALTER TABLE `colors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `endcats`
--
ALTER TABLE `endcats`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `header_fotter`
--
ALTER TABLE `header_fotter`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `midcats`
--
ALTER TABLE `midcats`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_id` (`user_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_order_id` (`order_id`),
  ADD KEY `idx_product_id` (`product_id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `payment_method_id` (`payment_method_id`);

--
-- Indexes for table `payment_methods`
--
ALTER TABLE `payment_methods`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `method_name` (`method_name`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sizes`
--
ALTER TABLE `sizes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `social_link`
--
ALTER TABLE `social_link`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `topcats`
--
ALTER TABLE `topcats`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `uselinks`
--
ALTER TABLE `uselinks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `colors`
--
ALTER TABLE `colors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `endcats`
--
ALTER TABLE `endcats`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `header_fotter`
--
ALTER TABLE `header_fotter`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT for table `midcats`
--
ALTER TABLE `midcats`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payment_methods`
--
ALTER TABLE `payment_methods`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `sizes`
--
ALTER TABLE `sizes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `social_link`
--
ALTER TABLE `social_link`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `topcats`
--
ALTER TABLE `topcats`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `uselinks`
--
ALTER TABLE `uselinks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `payments_ibfk_2` FOREIGN KEY (`payment_method_id`) REFERENCES `payment_methods` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

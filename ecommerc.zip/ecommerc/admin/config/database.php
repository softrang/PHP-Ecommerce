<?php
session_start();

class DatabaseConnection
{
    private static $conn = null; // Static property to hold the connection

    // Constructor to initialize database connection parameters
    private function __construct($host, $port, $dbname, $username, $password)
    {
        // Create the connection if not already created
        if (self::$conn === null) {
            self::$conn = new mysqli($host, $username, $password, $dbname, $port) ;

            // Check for connection errors
            if (self::$conn->connect_error) {
                throw new Exception("Failed to connect to the database: ");
                    
            }
        }
    }

    // Static method to get the connection
    public static function getConnection($host, $port, $dbname, $username, $password)
    {
        // Call constructor only if connection hasn't been created yet
        if (self::$conn === null) {
            new DatabaseConnection($host, $port, $dbname, $username, $password);
        }

        return self::$conn;
    }

    // Function to update .env file
    public static function updateEnvFile($host, $port, $dbname, $username, $password)
    {
        $envContent = "DB_HOST=$host\n";
        $envContent .= "DB_PORT=$port\n";
        $envContent .= "DB_DATABASE=$dbname\n";
        $envContent .= "DB_USERNAME=$username\n";
        $envContent .= "DB_PASSWORD=$password\n";

        if (file_put_contents('.env', $envContent) === false) {
            throw new Exception("Failed to update the .env file. Please check file permissions.");
        }
    }
}

// Base URL for redirection
$baseUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/ecommerc';




?>

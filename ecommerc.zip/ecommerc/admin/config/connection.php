
<?php
include_once __DIR__.'./database.php';

$erore='';

// If form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize input values
    $host = $_POST['host'];
    $port = $_POST['port'];
    $dbname = $_POST['dbname'];
    $username = $_POST['dbusername'];
    $password = $_POST['dbpassword'];

    try {
        // Attempt to connect to the database (Global Connection)
        $conn = DatabaseConnection::getConnection($host, $port, $dbname, $username, $password);

        // Save details to session securely
        $_SESSION['db_details'] = [
            'host' => $host,
            'port' => $port,
            'dbname' => $dbname,
            'username' => $username,
            'password' => $password
        ];

        // Update the .env file with the new details
        DatabaseConnection::updateEnvFile($host, $port, $dbname, $username, $password);

        echo "Connected successfully! Redirecting to the homepage...";

        // Use header redirection after processing
        header('Location: ' . $baseUrl . '/index.php');
        exit();
    } catch (Exception $e) {
         $erore=  "Error: Check your details and try again. ";
    }
}



?>








<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database Connection Form</title>

    <style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f9;
        margin: 0;
        padding: 0;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        height: 100vh;
        overflow: hidden;
    }

    h2 {
        text-align: center;
        color: #333;
    }

    form {
        background-color: #fff;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        max-width: 400px;
        width: 100%;
        overflow: hidden;
    }

    .form-row {
        display: flex;
        flex-direction: column;
        margin-bottom: 15px;
    }

    label {
        font-size: 14px;
        color: #555;
        margin-bottom: 5px;
    }

    input {
        padding: 10px;
        font-size: 14px;
        border: 1px solid #ddd;
        border-radius: 5px;
        transition: border-color 0.3s ease;
    }

    input:focus {
        border-color: #007BFF;
        outline: none;
    }

    button {
        padding: 10px 20px;
        background-color: #007BFF;
        color: #fff;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-size: 16px;
        transition: background-color 0.3s ease;
    }

    button:hover {
        background-color: #0056b3;
    }

    .form-row:last-child {
        text-align: center;
    }
</style>


</head>
<body>
<h2>Database Connection Form</h2>
<form method="POST" action="">
    <div class="form-row">
        <label for="host">Host:</label>
        <input type="text" id="host" name="host" required>
    </div>
    <div class="form-row">
        <label for="port">Port:</label>
        <input type="text" id="port" name="port" value="3306" required>
    </div>
    <div class="form-row">
        <label for="dbname">Database Name:</label>
        <input type="text" id="dbname" name="dbname" required>
    </div>
    <div class="form-row">
        <label for="dbusername">dbUsername:</label>
        <input type="text" id="dbusername" name="dbusername" required>
    </div>
    <div class="form-row">
        <label for="dbpassword">dbPassword:</label>
        <input type="password" id="dbpassword" name="dbpassword">
    </div>
   <div class="form-row">
        <p><?php echo $erore ?> </p>
    </div>
   <div class="form-row">
        <button type="submit">Submit</button>
    </div>
</form>

</body>
</html>

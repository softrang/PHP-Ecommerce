<?php
// Load the Dotenv library
require_once __DIR__ . '/vendor/autoload.php';

use Dotenv\Dotenv;
global $conn;
// Load the .env file
$dotenv = Dotenv::createImmutable(__DIR__ ); // .env ফাইল যেখানে আছে সেই ডিরেক্টরি পাথ দিন
$dotenv->load();

// Get the environment (local or live)
$appEnv = $_ENV['APP_ENV'] ?? 'local';

// Configure the base URL based on the environment
if ($appEnv === 'live') {
    $baseUrl = $_ENV['LIVE_URL'];
} else {
    $baseUrl = $_ENV['LOCAL_URL'];
}

// Output the base URL for debugging
echo "Base URL: $baseUrl";


// ডাটাবেস কানেকশনের ডেটা .env থেকে লোড করুন
$host = $_ENV['DB_HOST'];
$port = $_ENV['DB_PORT'];
$dbname = $_ENV['DB_DATABASE'];
$username = $_ENV['DB_USERNAME'];
$password = $_ENV['DB_PASSWORD'];

// ডাটাবেস কানেকশন তৈরি করুন
$conn = new mysqli($host, $username, $password, $dbname, $port);

// কানেকশনে কোনো সমস্যা হলে স্ক্রিপ্ট বন্ধ করুন
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

<?php
include_once __DIR__ . '/config/database.php';

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

global $conn;
$invalid="";
// Load .env variables manually
$env = parse_ini_file(__DIR__.'/config/.env');

// Fetch variables
$host = $env['DB_HOST'];
$username = $env['DB_USERNAME'];
$password = $env['DB_PASSWORD'];
$dbname = $env['DB_DATABASE'];
$port = $env['DB_PORT'];

$conn = new mysqli($host, $username, $password, $dbname, $port);

// Create Users table if it doesn't exist
$tableCreationQuery = "
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(15) NOT NULL,
    address TEXT NOT NULL,
    role ENUM('super_admin', 'staf') DEFAULT 'staf',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);";

if ($conn->query($tableCreationQuery) !== TRUE) {
    die("Error creating table: " . $conn->error);
}

// Insert default Super Admin user if not exists
$defaultAdminPassword = password_hash('admin', PASSWORD_BCRYPT);

$defaultUserQuery = "
INSERT INTO users (name, email, password, role, phone, address) 
SELECT 'admin', 'admin@example.com', '$defaultAdminPassword', 'super_admin', '+8801111111111111', 'Dhaka Bangladesh'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email = 'admin@example.com')
";

if ($conn->query($defaultUserQuery) !== TRUE) {
    die("Error inserting default user: " . $conn->error);
}

if (isset($_POST["submit"])) {
    $username = trim($_POST['adusername'] ?? '');
    $password = trim($_POST['adpassword'] ?? '');

    if (empty($username) || empty($password)) {
        echo "adUsername and adpassword are required!";
        exit;
    }

    $stmt = $conn->prepare("SELECT id, password, role FROM users WHERE name = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($id, $hashed_password, $role);
        $stmt->fetch();

        if (password_verify($password, $hashed_password)) {
            $_SESSION['user_id'] = $id;
          
            header('location: pages/dashboard.php');

           
        } else {
            $invalid=  "Invalid credentials!";
        }
    } else {
        echo "<div class='error'>User not found!</div>";
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(to right, #00b4db, #0083b0);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .login-container {
            background: #fff;
            padding: 2rem;
            border-radius: 10px;
            box-shadow: 0px 4px 20px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 400px;
        }
        .login-container h2 {
            margin-bottom: 1.5rem;
            text-align: center;
            color: #333;
        }
        .login-container form {
            display: flex;
            flex-direction: column;
        }
        .login-container input {
            margin-bottom: 1rem;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 1rem;
        }
        .login-container button {
            background: #0083b0;
            color: #fff;
            border: none;
            padding: 10px;
            font-size: 1rem;
            border-radius: 5px;
            cursor: pointer;
            transition: background 0.3s ease;
        }
        .login-container button:hover {
            background: #00b4db;
        }
        .error {
            color: red;
            font-size: 0.9rem;
            text-align: center;
            margin-bottom: 1rem;
        }
        @media (max-width: 480px) {
            .login-container {
                padding: 1.5rem;
            }
            .login-container h2 {
                font-size: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h2>Login</h2>
        <form method="POST" action="">
            <input type="text" name="adusername" placeholder="Username" required>
            <input type="password" name="adpassword" placeholder="Password" required>
            <p> <?php $invalid?> </p>
            <button name="submit" type="submit">Login</button>
        </form>
    </div>
</body>
</html>

<?php
include_once __DIR__ . '/../config/database.php';
//include_once __DIR__.'/../../routs/allrous.php';

// Load environment variables
$env = parse_ini_file(__DIR__.'/../config/.env');

// Fetch variables from the .env file
$host = $env['DB_HOST'];
$username = $env['DB_USERNAME'];
$password = $env['DB_PASSWORD'];
$dbname = $env['DB_DATABASE'];
$port = $env['DB_PORT'];

// Database connection
$conn = new mysqli($host, $username, $password, $dbname, $port);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create table if not exists
$table_query = "CREATE TABLE IF NOT EXISTS images (
    id INT AUTO_INCREMENT PRIMARY KEY,
    image_name VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    update_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)";
$conn->query($table_query);

// Folder configuration
$upload_dir = '../../uploads';
if (!file_exists($upload_dir)) {
    if (!mkdir($upload_dir, 0777, true)) {
        die("Failed to create upload directory.");
    }
}

// Handling form submission
if (isset($_POST['submit'])) {
    if (isset($_FILES['slideimage']['name']) && !empty($_FILES['slideimage']['name'])) {
        $file_name = basename($_FILES['slideimage']['name']); // Sanitize the file name
        $temp_name = $_FILES['slideimage']['tmp_name'];
        $unique_name = uniqid() . "_" . $file_name;
        $target_file = $upload_dir . "/" . $unique_name;
        $relative_path = $unique_name; // Save only the relative path in the database

        // Check for valid upload
        if (move_uploaded_file($temp_name, $target_file)) {
            // Use prepared statement to insert into database
            $stmt = $conn->prepare("INSERT INTO images (image_name) VALUES (?)");
            $stmt->bind_param("s", $unique_name);

            if ($stmt->execute()) {
                echo "Image uploaded and saved successfully!";
            } else {
                echo "Error saving to database: " . $conn->error;
            }

            $stmt->close();
        } else {
            echo "Error uploading file!";
        }
    } else {
        echo "No file selected.";
    }
}
// Edit image
// Handle the edit request
if (isset($_POST['edit'])) {
    $id = $_POST['id'];
    $select_query = "SELECT * FROM images WHERE id = $id";
    $result = $conn->query($select_query);
    $row = $result->fetch_assoc(); 




}

if (isset($_POST['update'])) {
    $id = $_POST['id'];
     echo $id;

    // Fetch the current image path from the database
    $select_query = $conn->prepare("SELECT image_name FROM images WHERE id = ?");
    $select_query->bind_param("i", $id);
    $select_query->execute();
    $result = $select_query->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $old_image_path = "../../uploads/". $row['image_name']; // Get the old image path
    } else {
        die("Image not found for ID: $id");
    }

    // Check if a new image is uploaded
    if (isset($_FILES['slideimage']['name']) && !empty($_FILES['slideimage']['name'])) {
        $file_name = $_FILES['slideimage']['name'];
        $temp_name = $_FILES['slideimage']['tmp_name'];
        $unique_name = uniqid() . "_" . $file_name;
        $upload_dir = __DIR__ . "/../../uploads";
        $target_file = $upload_dir . "/" . $unique_name;

        // Move the new uploaded image to the uploads folder
        if (move_uploaded_file($temp_name, $target_file)) {
            // Delete the old image file if it exists
            if (file_exists($old_image_path)) {
                unlink($old_image_path);
            }

            // Update the database with the new image path
            $update_query = $conn->prepare("UPDATE images SET image_name = ? WHERE id = ?");
            $update_query->bind_param("si", $unique_name, $id);

            if ($update_query->execute()) {
                echo "Image updated successfully!";
            } else {
                echo "Error updating image in database: " . $update_query->error;
            }
        } else {
            echo "Error uploading new image!";
        }
    } else {
        // Update only the image name or other details if no new image is uploaded
        $new_image_name = $_POST['image_name']; // Assuming a new name or other details are provided
        $update_query = $conn->prepare("UPDATE images SET image_name = ? WHERE id = ?");
        $update_query->bind_param("si", $new_image_name, $id);

        if ($update_query->execute()) {
            echo "Image details updated successfully!";
        } else {
            echo "Error updating image: " . $update_query->error;
        }
    }
}








// Delete image
if (isset($_POST['delete'])) {
    $id = $_POST['id']; // ID of the image to be deleted
    $delete_query = "SELECT image_name FROM images WHERE id = $id";
    $result = $conn->query($delete_query);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $image_path = "../../uploads/". $row['image_name'];

        if (file_exists($image_path)) {
            echo "File exists: " . $image_path; // Debugging line
            if (unlink($image_path)) {
                echo "Image file deleted successfully!";
            } else {
                echo "Failed to delete image file.";
            }
        } else {
            echo "File not found: " . $image_path; // Debugging line
        }
        

        $delete_query = "DELETE FROM images WHERE id = $id";
        if ($conn->query($delete_query)) {
            echo "Image deleted successfully!";
        } else {
            echo "Error deleting from database: " . $conn->error;
        }
    } else {
        echo "Image not found!";
    }
}

// Fetch data from database


    $data_query = "SELECT * FROM images";
    $result = $conn->query($data_query);

?>





<?php include(__DIR__ . '/../../views/layouts/admin/header.php');?>
    <div class="container">
        <!-- Sidebar -->
        <?php include(__DIR__ . '/../../views/layouts/admin/sidebar.php'); ?>

        <!-- Main Content -->
        <main class="main-content">
            <h2> All Slider</h2>
            <div class="slider-wrap">
                <div class="slider-display">
                    <table>
                        <thead>
                            <tr>
                                <th>SL</th>
                                <th>Image</th>
                                <th>Action</th>
                                
                            </tr>
                        </thead>
                        <tbody>
                        <?php

// Check if the result is valid and has rows
if ($result && $result->num_rows > 0): 
    while ($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?php echo $row['id']; ?></td>

            <!-- Display image -->
            <td>
                <img src="../../uploads/<?php echo htmlspecialchars($row['image_name'], ENT_QUOTES, 'UTF-8'); ?>" alt="Image" width="100">
            </td>

            <!-- Action buttons for Edit and Delete -->
            <td>
                <form action="" method="POST" style="display:inline;">
                    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                    <button type="submit" name="edit">Edit</button>
                </form>

                <form action="" method="POST" style="display:inline;">
                    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                    <button style="background-color: #ce2828 ;" type="submit" name="delete">Delete</button>
                </form>
            </td>
        </tr>
    <?php endwhile; 
else: ?>
    <tr>
        <td colspan="3">No images found.</td>
    </tr>
<?php endif; ?>






                        </tbody>
                    </table>

                </div>
                <div class="slider-input">
                <?php if (isset($_POST['edit'])) : ?>
    <form action="" method="POST" enctype="multipart/form-data">
        <input type="hidden" name="id" value="<?php echo $_POST['id']; ?>">

                <!-- Input for new image upload -->
        <label for="slideimage">Change Image:</label>
        <input type="file" name="slideimage" accept="image/png" ><br>

        <button type="submit" name="update">Update</button>
    </form>
    
<?php else:?>
    
    <form method="Post" action="" enctype="multipart/form-data">
        <label>Add Image </label>
        <input type="file" name="slideimage" accept="image/png" />
        <button name="submit">Add Slider</button>
        
<?php endif?>

                    </form>

                </div>

            </div>
            
            
            <?php include(__DIR__ . '/../../views/layouts/admin/fotter.php'); ?>
        </main>
    </div>
 <!-- fotter -->




    <?php include(__DIR__ . '/../../views/layouts/admin/header.php');?>
    <div class="container">
        <!-- Sidebar -->
        <?php include(__DIR__ . '/../../views/layouts/admin/sidebar.php'); ?>

        <!-- Main Content -->
        <main class="main-content">
            <h1>Welcome to the Dashboard</h1>
            <p>This is the main content area.</p>

            
            <?php include(__DIR__ . '/../../views/layouts/admin/fotter.php'); ?>
        </main>

 <!-- fotter -->

 </div>
<?php
// Include database configuration
include_once __DIR__ . '/../config/database.php';
include_once __DIR__ . '/../../controllars/databasequery.php';

// Load environment variables
$env = parse_ini_file(__DIR__.'/../config/.env');

// Fetch variables
$host = $env['DB_HOST'];
$username = $env['DB_USERNAME'];
$password = $env['DB_PASSWORD'];
$dbname = $env['DB_DATABASE'];
$port = $env['DB_PORT'];

$conn = new mysqli($host, $username, $password, $dbname, $port);



if (isset($_POST['submit'])) {
    $p_t_cat = $_POST['p_t_cat'];
    $p_m_cat = $_POST['p_m_cat'];
    $p_e_cat = $_POST['p_e_cat'];
    $p_title = $_POST['p_title'];
    $p_price = $_POST['p_price']; // Fixed typo from "p_prise" to "p_price"
    $p_discount = $_POST['p_discount'];
    $p_stock = $_POST['p_stock'];

    // Convert sizes and colors arrays to comma-separated strings
    $p_size = isset($_POST['selectedSizes']) ? implode(',', $_POST['selectedSizes']) : '';
    $p_color = isset($_POST['selectedColors']) ? implode(',', $_POST['selectedColors']) : '';

    $p_brand = $_POST['p_brand'];
    $p_s_dis = $_POST['p_s_dis'];
    $p_dis = $_POST['p_dis'];
    $p_is_lataset = $_POST['p_is_lataset'];
    $p_is_future = $_POST['p_is_future'];
    $p_is_discount = $_POST['p_is_discount'];

    $p_thumb_image_name = $_FILES['p_thumb_image']['name'];
    $p_thumb_image_temp_name = $_FILES['p_thumb_image']['tmp_name'];

    $p_future_image_names = $_FILES['p_future_image']['name'];
    $p_future_image_temp_names = $_FILES['p_future_image']['tmp_name'];

    // Create "products" table if it does not exist
    $createTableSQL = "
        CREATE TABLE IF NOT EXISTS products (
            id INT AUTO_INCREMENT PRIMARY KEY,
            t_cat VARCHAR(255),
            m_cat VARCHAR(255),
            e_cat VARCHAR(255),
            p_title VARCHAR(255),
            p_price FLOAT,
            p_discount FLOAT,
            p_stock INT,
            p_sizes VARCHAR(255),
            p_colors VARCHAR(255),
            p_brand VARCHAR(255),
            p_is_future VARCHAR(255),
            p_is_lataset VARCHAR(255),
            p_is_discount VARCHAR(255),
            p_s_dis TEXT,
            p_dis TEXT,
            thumb_image VARCHAR(255),
            future_images  VARCHAR(255),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )";
    $conn->query($createTableSQL);

// Folder configuration
$upload_product_dir = '../../uploads/products';
if (!file_exists($upload_product_dir)) {
    if (!mkdir($upload_product_dir, 0777, true)) {
        die("Failed to create upload directory.");
    }
}

    // Upload thumbnail image
    $thumbImageName = uniqid()."_" . basename($p_thumb_image_name);
    $thumbImagePath = $upload_product_dir."/" . $thumbImageName;
    if (!empty($p_thumb_image_name) && move_uploaded_file($p_thumb_image_temp_name, $thumbImagePath)) {
        echo "Thumbnail image uploaded successfully.";
    } else {
        echo "Failed to upload thumbnail image.";
        $thumbImagePath = ""; // Fallback if upload fails
    }

    $futureImageNames = []; // Array to store unique image names for the database

    if (!empty($p_future_image_names)) {
        foreach ($p_future_image_names as $key => $futureImage) {
            if (isset($p_future_image_temp_names[$key])) {
                // Generate a unique name for the image
                $futureImageName = "futureimage_". uniqid() . "_" . basename($futureImage);
                $futureImagePath = $upload_product_dir."/". $futureImageName;
    
                // Ensure the upload directory exists
                if (!is_dir($upload_product_dir)) {
                    mkdir($upload_product_dir, 0755, true);
                }
    
                // Move the uploaded file to the specified directory
                if (move_uploaded_file($p_future_image_temp_names[$key], $futureImagePath)) {
                    $futureImageNames[] = $futureImageName; // Add the unique image name to the array
                } else {
                    error_log("Failed to move uploaded file: " . $p_future_image_temp_names[$key]);
                }
            } else {
                error_log("Temporary file missing for key: $key");
            }
        }
    }
    
    // Convert the array of image names to a comma-separated string
    $futureImageNameString = implode(",", $futureImageNames);
    
    // Debugging outputs
    var_dump($futureImageNames); // Should show the array of processed image names
    var_dump($futureImageNameString); // Should show the comma-separated string
    
    if (empty($futureImageNames)) {
        echo "No images were uploaded. Please check for errors.";
    } else {
        echo "Thumbnail images uploaded successfully.";
    }
    
    // Insert data into database
    $stmt = $conn->prepare("
        INSERT INTO products 
        (t_cat, m_cat, e_cat, p_title, p_price, p_discount, p_stock, p_sizes, p_colors, p_brand, p_is_future, p_is_lataset, p_is_discount, p_s_dis, p_dis, thumb_image, future_images) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    $stmt->bind_param(
        "ssssddissssssssss",
        $p_t_cat,
        $p_m_cat,
        $p_e_cat,
        $p_title,
        $p_price,
        $p_discount,
        $p_stock,
        $p_size,
        $p_color,
        $p_brand,
        $p_is_future,
        $p_is_lataset,
        $p_is_discount,
        $p_s_dis,
        $p_dis,
        $thumbImageName,
        $futureImageNameString,
    );

    if ($stmt->execute()) {
        echo "Product added successfully.";
        header("location:". $_SERVER["PHP_SELF"]);
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
   
}






if (isset($_POST['update'])) {
    $product_id = $_POST['product_id']; // প্রোডাক্ট আইডি
    $p_t_cat = $_POST['p_t_cat'];
    $p_m_cat = $_POST['p_m_cat'];
    $p_e_cat = $_POST['p_e_cat'];
    $p_title = $_POST['p_title'];
    $p_price = $_POST['p_price'];
    $p_discount = $_POST['p_discount'];
    $p_stock = $_POST['p_stock'];

    $p_size = isset($_POST['selectedSizes']) ? implode(',', $_POST['selectedSizes']) : '';
    $p_color = isset($_POST['selectedColors']) ? implode(',', $_POST['selectedColors']) : '';

    $p_brand = $_POST['p_brand'];
    $p_s_dis = $_POST['p_s_dis'];
    $p_dis = $_POST['p_dis'];
    $p_is_lataset = $_POST['p_is_lataset'];
    $p_is_future = $_POST['p_is_future'];
    $p_is_discount = $_POST['p_is_discount'];

    $p_thumb_image_name = $_FILES['p_thumb_image']['name'];
    $p_thumb_image_temp_name = $_FILES['p_thumb_image']['tmp_name'];

    $p_future_image_names = $_FILES['p_future_image']['name'];
    $p_future_image_temp_names = $_FILES['p_future_image']['tmp_name'];



// Folder configuration
$upload_product_dir = '../../uploads/products';
if (!file_exists($upload_product_dir)) {
    if (!mkdir($upload_product_dir, 0777, true)) {
        die("Failed to create upload directory.");
    }
}





   // Fetch old images from the database
   $stmt = $conn->prepare("SELECT thumb_image, future_images FROM products WHERE id = ?");
   $stmt->bind_param("i", $product_id);
   $stmt->execute();
   $result = $stmt->get_result();
   $oldImages = $result->fetch_assoc();
   $stmt->close();

   // Delete old thumbnail image
   if (!empty($oldImages['thumb_image'])) {
       $oldThumbPath = $upload_product_dir . "/" . $oldImages['thumb_image'];
       if (file_exists($oldThumbPath)) {
           unlink($oldThumbPath);
       }
   }

   // Delete old future images
   if (!empty($oldImages['future_images'])) {
       $oldFutureImages = explode(",", $oldImages['future_images']);
       foreach ($oldFutureImages as $oldFutureImage) {
           $oldFuturePath = $upload_product_dir . "/" . $oldFutureImage;
           if (file_exists($oldFuturePath)) {
               unlink($oldFuturePath);
           }
       }
   }

   // Upload new thumbnail image
   $thumbImageName = uniqid() . "_" . basename($p_thumb_image_name);
   $thumbImagePath = $upload_product_dir . "/" . $thumbImageName;
   if (!empty($p_thumb_image_name) && move_uploaded_file($p_thumb_image_temp_name, $thumbImagePath)) {
       echo "Thumbnail image uploaded successfully.";
   } else {
       echo "Failed to upload thumbnail image.";
       $thumbImageName = ""; // Fallback if upload fails
   }

   // Upload new future images
   $futureImageNames = [];
   if (!empty($p_future_image_names)) {
       foreach ($p_future_image_names as $key => $futureImage) {
           if (isset($p_future_image_temp_names[$key])) {
               $futureImageName = "futureimage_" . uniqid() . "_" . basename($futureImage);
               $futureImagePath = $upload_product_dir . "/" . $futureImageName;

               if (move_uploaded_file($p_future_image_temp_names[$key], $futureImagePath)) {
                   $futureImageNames[] = $futureImageName;
               } else {
                   error_log("Failed to move uploaded file: " . $p_future_image_temp_names[$key]);
               }
           } else {
               error_log("Temporary file missing for key: $key");
           }
       }
   }
   $futureImageNameString = implode(",", $futureImageNames);

    // Update Query
    $stmt = $conn->prepare("
        UPDATE products 
        SET 
            t_cat = ?, 
            m_cat = ?, 
            e_cat = ?, 
            p_title = ?, 
            p_price = ?, 
            p_discount = ?, 
            p_stock = ?, 
            p_sizes = ?, 
            p_colors = ?, 
            p_brand = ?, 
            p_is_future = ?, 
            p_is_lataset = ?, 
            p_is_discount = ?, 
            p_s_dis = ?, 
            p_dis = ?, 
            thumb_image = ?, 
            future_images = ?
        WHERE id = ?
    ");

    $stmt->bind_param(
        "ssssddissssssssssi",
        $p_t_cat,
        $p_m_cat,
        $p_e_cat,
        $p_title,
        $p_price,
        $p_discount,
        $p_stock,
        $p_size,
        $p_color,
        $p_brand,
        $p_is_future,
        $p_is_lataset,
        $p_is_discount,
        $p_s_dis,
        $p_dis,
        $thumbImageName,
        $futureImageNameString,
        $product_id
    );

    if ($stmt->execute()) {
        echo "Product updated successfully.";
        header("location:". $_SERVER["PHP_SELF"]);

    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}




if (isset($_POST['Delete'])) {
    // Fetch the ID of the record to delete
    $id = $_POST['id']; // Assuming the ID is being passed in the POST request

    // Step 1: Get the file paths of the images
    $query = "SELECT thumb_image, future_images FROM products WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $thumb_image_path = "../../uploads/products/" . $row['thumb_image']; // Path for thumbnail image
        $future_images = $row['future_images']; // Future images (assume comma-separated paths)

        // Step 2: Delete the thumbnail image
        if (file_exists($thumb_image_path)) {
            unlink($thumb_image_path); // Deletes the thumbnail image
        }

        // Step 3: Delete future images
        if (!empty($future_images)) {
            $future_images_paths = explode(',', $future_images); // Assuming comma-separated file paths
            foreach ($future_images_paths as $image_path) {
                $full_path = "../../uploads/products/" . trim($image_path); // Add base path
                if (file_exists($full_path)) {
                    unlink($full_path); // Deletes each future image
                }
            }
        }

        // Step 4: Delete the record from the database
        $query = "DELETE FROM products WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param('i', $id);

        if ($stmt->execute()) {
            echo "<script>alert('Record and associated images deleted successfully!');</script>";
            header("Location: " . $_SERVER['PHP_SELF']); // Refresh the page
            exit; // Ensure no further code execution
        } else {
            echo "<script>alert('Failed to delete record. Please try again.');</script>";
        }
    } else {
        echo "<script>alert('No record found with the specified ID.');</script>";
    }

    $stmt->close();
}





// Fetch All Tabile for display
$topCats = getTabile($conn, 'topcats');
$midCats = getTabile($conn, 'midcats');
$endCats = getTabile($conn, 'endcats');
$Sizes = getTabile($conn, 'sizes');
$Colors = getTabile($conn, 'colors');
$Brands = getTabile($conn, 'brands');
$products = getTabile($conn, 'products');



?>


<?php include(__DIR__ . '/../../views/layouts/admin/header.php');?>
    <div class="container">
        <!-- Sidebar -->
        <?php include(__DIR__ . '/../../views/layouts/admin/sidebar.php'); ?>

        <!-- Main Content -->
        <main class="main-content">
            <div class="search-add-wrap">
                <div class="search-display">
                    <div class="search-shows"> 
                       <label> Shows</label>  
                    <select>
                        <option>20</option>
                        <option>50</option>
                        <option>100</option>
                    </select>
                    </div>
                    <input type="search" placeholder="Serach Product By ID"/>

                </div>
                <div class="search-add">
                    

                <button onclick="openAddModal()">Add Product</button>
                     
                    

                </div>
               
            </div>


            <div class="produc-input">
<?php
            // Prepare data for JavaScript
$categoriesByTopCat = [];
foreach ($midCats as $midCat) {
    $categoriesByTopCat[$midCat['midtopcat']][] = $midCat['midcat'];
}

$categoriesByMidCat = [];
foreach ($endCats as $endCat) {
    $categoriesByMidCat[$endCat['endmidcat']][] = $endCat['endcat'];
}
?>


<div id="productModal" class="modal">
    <div class="modal-content product-input">
        <span class="close" id="closeModalBtn">&times;</span>
        <h2 id="modalTitle">Add New Product</h2>

        <form id="form" method="POST" action="" enctype="multipart/form-data">
            <input type="hidden" name="product_id" id="productId" value=""> <!-- Hidden field for editing -->
            <label>Select Category</label>

            <select  id="topCategory" name="p_t_cat">
                <option value="">Select Top Category</option>
                <?php foreach ($topCats as $cat) { ?>
                    <option value="<?php echo $cat['topcat']; ?>"><?php echo $cat['topcat']; ?></option>
                <?php } ?>
            </select>

            <select id="midCategory" name="p_m_cat" disabled>
                <option value="">Select Mid Category</option>
            </select>

            <select id="endCategory" name="p_e_cat" disabled>
                <option value="">Select End Category</option>
            </select>

            <label>Title</label>
            <input type="text" name="p_title" id="productTitle" placeholder="Enter the product Title"/>

            <label>Price</label>
            <input type="number" name="p_price" id="productPrice" placeholder="Enter the current Price"/>

            <label>Discount</label>
            <input type="number" name="p_discount" id="productDiscount" placeholder="Enter the discount Price"/>

            <label>Stock Amount</label>
            <input type="number" name="p_stock" id="productStock" placeholder="Enter the stock amount"/>

            <label>Size</label>
            <div id="selectedSizesContainer" style="display: flex; gap: 10px;"></div>
            <input type="hidden" id="selectedSizes" name="selectedSizes[]">
            <select id="sizeSelect" onchange="updateSelectedSize()">
                <option>Select Sizes</option>
                <?php if (!empty($Sizes)) {
                    foreach ($Sizes as $size) { ?>
                        <option value="<?php echo $size['size_name']; ?>"><?php echo $size['size_name']; ?></option>
                    <?php }
                } ?>
            </select>

            <label>Color</label>
            <div id="selectedColorsContainer" style="display: flex; gap: 10px;"></div>
            <input type="hidden" id="selectedColors" name="selectedColors[]">
            <select id="colorSelect" onchange="updateSelectedColor()">
                <option>Select Color</option>
                <?php if(!empty($Colors)){
                    foreach($Colors as $color){ ?>
                        <option><?php echo $color['color_name']?></option>
                    <?php  }
                }?>
            </select>

            <label>Brand</label>
            <select name="p_brand" id="productBrand">
                <option>Select Brand</option>
                <?php if(!empty($Brands)){
                    foreach($Brands as $brand){ ?>
                        <option value="<?php echo $brand['brand_name']?>"><?php echo $brand['brand_name']?></option>
                    <?php  }
                }?>
            </select>

            <label for="fileInput">Thumbnail Image</label>
            <div class="thumb-image">
                <input name="p_thumb_image" type="file" id="fileInput" accept="image/png" onchange="previewImage(event)" />
                <img id="imagePreview" src="" alt="Image Preview" style="display: none; max-width: 100%;"/>
            </div>

            <label>Future Image</label>
            <div class="image-container" id="image-container"></div>
            <input type="text" name="p_fut_image[]" id="future_image_names">
            <input type="file" name="p_future_image[]" id="file-upload" accept="image/png" multiple />
            <input type="button" id="add-images" value="Add Image"/>

            <label>Is it Future Product?</label>
            <select name="p_is_future">
                <option>Yes</option>
                <option>No</option>
            </select>

            <label>Is it Latest Product?</label>
            <select name="p_is_lataset">
                <option>Yes</option>
                <option>No</option>
            </select>

            <label>Is it Discount Product?</label>
            <select name="p_is_discount">
                <option>Yes</option>
                <option>No</option>
            </select>

            <label>Short Description</label>
            <textarea name="p_s_dis"></textarea>

            <label>Description</label>
            <textarea name="p_dis"></textarea>

            <button type="submit" name="submit" id="submitBtn">Submit</button>
            <button type="submit" name="update" id="updateBtn">Update</button>
        </form>
    </div>
</div>
            </div>
            
            <div class="product-display">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Image</th>
                            <th>Title</th>
                            <th>Sizes</th>
                            <th>Brands</th>
                            <th>Colors</th>
                            <th>Prise</th>
                            <th>Discunt</th>
                            <th>stock</th>
                            <th>Catagory</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(!empty($products)):?>
                            <?php foreach($products as $product):?>
                        <tr>

                            <td> <?php echo $product["id"]?></td>
                            <td><img src="<?php echo '../../uploads/products/' . $product['thumb_image']; ?>" alt="Product Image"/></td>

                            <td><?php echo $product["p_title"] ?></td>
                            <td><?php echo $product["p_sizes"] ?></td>
                            <td><?php echo $product["p_brand"] ?></td>
                            <td><?php echo $product["p_colors"] ?></td>
                            <td><?php echo $product ["p_price"]?></td>
                            <td><?php echo $product["p_discount"]?></td>
                            <td><?php echo $product["p_stock"]?></td>
                            <td>
                            <?php 
                            echo $product["t_cat"] . ",<br>" . 
                                $product["m_cat"] . ".<br>" . 
                                $product["e_cat"]; 
                            ?>
                        </td>
                            <td>
            <!-- Action Buttons -->
            <button onclick="openEditModal(
    <?php echo $product['id']; ?>, 
    '<?php echo addslashes($product["p_title"]); ?>', 
    '<?php echo addslashes($product["p_sizes"]); ?>',
    '<?php echo addslashes($product["p_brand"]); ?>', 
    '<?php echo addslashes($product["p_colors"]); ?>', 
    <?php echo $product["p_price"]; ?>, 
    <?php echo $product["p_discount"]; ?>, 
    <?php echo $product["p_stock"]; ?>,
    '<?php echo addslashes($product["t_cat"]); ?>'
)">Edit</button>
                <button onclick="openDeleteModal(<?php echo $product['id']; ?>)">Delete</button>
                <button onclick="openViewModal(<?php echo $product['id']; ?>)">View</button>
  
                            </td>
                        </tr>
                        <?php endforeach;?>
                        <?php else:?>
                            <td rowspan="7"> No product found </td>
                            <?php endif;?>
                    </tbody>
                </table>
            



<!-- Delete Modal -->
<div id="deleteModal" class="modal">
    <div class="modal-content modal-delete">
       
        <h2>Are you sure you want to delete this product?</h2>
        <form method="post" action="">
            <input type="hidden" name="id" id="deleteId">
            <button style="background-color: #ce2828 ;" type="submit" name="Delete">Delete</button>
            <button type="button" onclick="closeModal('deleteModal')">Cancel</button>
        </form>
    </div>
</div>

<!-- View Modal -->
<div id="viewModal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="closeModal('viewModal')">&times;</span>
        <h2>Product Details</h2>
        <p id="viewProductDetails"></p>
        <button onclick="closeModal('viewModal')">Close</button>
    </div>
</div>








            </div>
            <?php include(__DIR__ . '/../../views/layouts/admin/fotter.php'); ?>

            
        </main>

       

<!-- JavaScript -->
<script>
    // Data from PHP
    const categoriesByTopCat = <?php echo json_encode($categoriesByTopCat); ?>;
    const categoriesByMidCat = <?php echo json_encode($categoriesByMidCat); ?>;

    // DOM Elements
    const topCategory = document.getElementById('topCategory');
    const midCategory = document.getElementById('midCategory');
    const endCategory = document.getElementById('endCategory');

    // Populate Mid Categories based on Top Category
    topCategory.addEventListener('change', function () {
        const selectedTopCat = this.value;

        // Clear and disable Mid and End Categories
        midCategory.innerHTML = '<option value="">Select Mid Category</option>';
        endCategory.innerHTML = '<option value="">Select End Category</option>';
        midCategory.disabled = true;
        endCategory.disabled = true;

        // Populate Mid Categories
        if (selectedTopCat && categoriesByTopCat[selectedTopCat]) {
            categoriesByTopCat[selectedTopCat].forEach(midCat => {
                const option = document.createElement('option');
                option.value = midCat;
                option.textContent = midCat;
                midCategory.appendChild(option);
            });
            midCategory.disabled = false;
        }
    });

    // Populate End Categories based on Mid Category
    midCategory.addEventListener('change', function () {
        const selectedMidCat = this.value;

        // Clear and disable End Categories
        endCategory.innerHTML = '<option value="">Select End Category</option>';
        endCategory.disabled = true;

        // Populate End Categories
        if (selectedMidCat && categoriesByMidCat[selectedMidCat]) {
            categoriesByMidCat[selectedMidCat].forEach(endCat => {
                const option = document.createElement('option');
                option.value = endCat;
                option.textContent = endCat;
                endCategory.appendChild(option);
            });
            endCategory.disabled = false;
        }
    });

    let selectedSizes = []; // Array to store selected colors

function updateSelectedSize() {
    const sizeSelect = document.getElementById('sizeSelect');
    const selectedSize = sizeSelect.value;
    
    // Check if the selected color is not empty and is not already in the array
    if (selectedSize && !selectedSizes.includes(selectedSize)) {
        selectedSizes.push(selectedSize);
        renderSelectedSizes();
    }
}

function renderSelectedSizes() {
    const container = document.getElementById('selectedSizesContainer');
    container.innerHTML = ''; // Clear previous selections

    selectedSizes.forEach(Size => {
        const sizeChip = document.createElement('p');
        sizeChip.classList.add('selected-value');
        sizeChip.textContent = Size;

        // Create a remove button
        const removeButtonn = document.createElement('span');
        removeButtonn.classList.add('remove-btn');
        removeButtonn.textContent = '✖';
        removeButtonn.onclick = () => {
            removeSize(Size); // Call function to remove color
        };

        sizeChip.appendChild(removeButtonn);
        container.appendChild(sizeChip);
    });

    // Update the hidden input field with the selected colors
    document.getElementById('selectedSizes').value = selectedSizes.join(', ');
}

function removeSize(Size) {
    // Remove the color from the array
    selectedSizes = selectedSizes.filter(s => s !== Size);
    renderSelectedSizes(); // Re-render the selected colors
}


   
let selectedColors = []; // Array to store selected colors

function updateSelectedColor() {
    const colorSelect = document.getElementById('colorSelect');
    const selectedColor = colorSelect.value;
    
    // Check if the selected color is not empty and is not already in the array
    if (selectedColor && !selectedColors.includes(selectedColor)) {
        selectedColors.push(selectedColor);
        renderSelectedColors();
    }
}

function renderSelectedColors() {
    const container = document.getElementById('selectedColorsContainer');
    container.innerHTML = ''; // Clear previous selections

    selectedColors.forEach(color => {
        const colorChip = document.createElement('p');
        colorChip.classList.add('selected-value');
        colorChip.textContent = color;

        // Create a remove button
        const removeButton = document.createElement('span');
        removeButton.classList.add('remove-btn');
        removeButton.textContent = '✖';
        removeButton.onclick = () => {
            removeColor(color); // Call function to remove color
        };

        colorChip.appendChild(removeButton);
        container.appendChild(colorChip);
    });

    // Update the hidden input field with the selected colors
    document.getElementById('selectedColors').value = selectedColors.join(', ');
}

function removeColor(color) {
    // Remove the color from the array
    selectedColors = selectedColors.filter(c => c !== color);
    renderSelectedColors(); // Re-render the selected colors
}




const fileUpload = document.getElementById('file-upload');
const addImagesBtn = document.getElementById('add-images');
const imageContainer = document.getElementById('image-container');

let imageFiles = [];

// Function to render images in the container
function renderImages() {
    imageContainer.innerHTML = ''; // Clear the container
    imageFiles.forEach((file, index) => {
        const imageItem = document.createElement('div');
        imageItem.classList.add('image-item');

        const img = document.createElement('img');
        img.src = URL.createObjectURL(file);
        img.alt = file.name;

        // Add delete button
        const deleteBtn = document.createElement('span');
        deleteBtn.classList.add('remove-btn');
        deleteBtn.textContent = '✖';
        deleteBtn.onclick = () => deleteImage(index, img.src); // Pass image URL for cleanup

        imageItem.appendChild(img);
        imageItem.appendChild(deleteBtn);
        imageContainer.appendChild(imageItem);
    });

    document.getElementById('future_image_names').value = imageFiles.join(', ');


}

// Function to add selected images
addImagesBtn.addEventListener('click', () => {
    if (fileUpload.files.length > 0) {
        for (let file of fileUpload.files) {
            imageFiles.push(file); // Add files to array
        }
        renderImages(); // Render images after adding
        fileUpload.value = ''; // Reset the file input
    }
});

// Function to delete an image
function deleteImage(index, imageURL) {
    imageFiles.splice(index, 1); // Remove the file from array
    URL.revokeObjectURL(imageURL); // Revoke the object URL to free memory
    renderImages(); // Re-render the images
}

// Function to preview a single image (optional)
function previewImage(event) {
    const file = event.target.files[0];
    const reader = new FileReader();

    reader.onload = function () {
        const preview = document.getElementById('imagePreview');
        preview.src = reader.result;
        preview.style.display = 'block'; // Show the image
    };

    if (file) {
        reader.readAsDataURL(file);
    }
}




// Get modal and buttons

var closeModalBtn = document.getElementById("closeModalBtn");

// Open modal when the button is clicked
function openAddModal() {
    // Set the modal title for adding a new product
    document.getElementById('modalTitle').textContent = 'Add New Product';

    // Reset the form and hide the hidden product ID (for Add Product case)
    document.getElementById('form').reset();
    document.getElementById('productId').value = '';  // Clear the hidden product ID

    // Show the modal
    document.getElementById('productModal').style.display = 'block';
    document.getElementById('updateBtn').style.display = 'none';

}


// Close modal when the close button is clicked
closeModalBtn.onclick = function() {
    document.getElementById('productModal').style.display = 'none';
}

// Close modal if the user clicks anywhere outside of the modal
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}












//Modal open and close functions
function openEditModal(id, title, price, discount, tcat) {
    // Set the modal title for editing an existing product
    document.getElementById('modalTitle').textContent = 'Edit Product';

    // Fill the form with the product data passed to this function
    document.getElementById('productId').value = id;  // Set the hidden product ID
    document.getElementById('productTitle').value = title;
    document.getElementById('productPrice').value = price;
    document.getElementById('productDiscount').value = discount;
    //document.getElementById('topCatagory').selectedIndex = tcat;

    // Show the modal
    document.getElementById('productModal').style.display = 'block';
    document.getElementById('submitBtn').style.display = 'none';
}

function openDeleteModal(id) {
    document.getElementById('deleteModal').style.display = 'block';
    document.getElementById('deleteId').value = id;
}

function openViewModal(id) {
    document.getElementById('viewModal').style.display = 'block';
    // Use AJAX to fetch product details and display them
    document.getElementById('viewProductDetails').innerHTML = 'Loading...';
    // For now, use a placeholder or dynamic fetching logic
    // You can send an AJAX request to a PHP script that returns product info
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

// Close modals when clicking outside the modal content
window.onclick = function(event) {
    if (event.target.classList.contains('modal')) {
        closeModal(event.target.id);
    }
}






</script>


 <!-- fotter -->

 </div>
<?php
// Include database configuration
include_once __DIR__ . '/../config/database.php';

// Load environment variables
$env = parse_ini_file(__DIR__.'/../config/.env');

// Fetch variables from the .env file
$host = $env['DB_HOST'];
$username = $env['DB_USERNAME'];
$password = $env['DB_PASSWORD'];
$dbname = $env['DB_DATABASE'];
$port = $env['DB_PORT'];

// Database connection
$conn = new mysqli($host, $username, $password, $dbname, $port);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to create the table if it doesn't exist
function createTopCatsTable($conn) {
    // Create the table if it doesn't exist
    $createTableQuery = "CREATE TABLE IF NOT EXISTS topcats (
        id INT AUTO_INCREMENT PRIMARY KEY,
        topcat VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )";

    if (!$conn->query($createTableQuery)) {
        die("Error creating table: " . $conn->error);
    }
}
function createMidCatsTable($conn) {
    // Create the table if it doesn't exist
    $createTableQuery = "CREATE TABLE IF NOT EXISTS midcats (
        id INT AUTO_INCREMENT PRIMARY KEY,
        midtopcat VARCHAR(255) NOT NULL,
        midcat VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )";

    if (!$conn->query($createTableQuery)) {
        die("Error creating table: " . $conn->error);
    }
}
function createEndCatsTable($conn) {
    // Create the table if it doesn't exist
    $createTableQuery = "CREATE TABLE IF NOT EXISTS endcats (
        id INT AUTO_INCREMENT PRIMARY KEY,
        endtopcat VARCHAR(255) NOT NULL,
        endmidcat VARCHAR(255) NOT NULL,
        endcat VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )";

    if (!$conn->query($createTableQuery)) {
        die("Error creating table: " . $conn->error);
    }
}





// Function to insert data into the topcats table
function insertTopCat($conn, $topcat) {
    // Prepare the INSERT statement
    $insertQuery = "INSERT INTO topcats (topcat) VALUES (?)";

    if ($stmt = $conn->prepare($insertQuery)) {
        // Bind parameters and execute the query
        $stmt->bind_param("s",  $topcat);
        if ($stmt->execute()) {
            echo "Data inserted successfully.";
        } else {
            echo "Error inserting data: " . $stmt->error;
        }
        $stmt->close();
        header("Location: ".$_SERVER['PHP_SELF']); // Refresh the page
        exit;
    } else {
        echo "Error preparing statement: " . $conn->error;
    }
}
function insertMidCat($conn, $midcat, $midtopcat) {
    // Prepare the INSERT statement
    $insertQuery = "INSERT INTO midcats (midcat, midtopcat) VALUES (?,?)";

    if ($stmt = $conn->prepare($insertQuery)) {
        // Bind parameters and execute the query
        $stmt->bind_param("ss",  $midcat, $midtopcat);
        if ($stmt->execute()) {
            echo "Data inserted successfully.";
        } else {
            echo "Error inserting data: " . $stmt->error;
        }
        $stmt->close();
        header("Location: ".$_SERVER['PHP_SELF']); // Refresh the page
        exit;
    } else {
        echo "Error preparing statement: " . $conn->error;
    }
}
function insertEndCat($conn, $endcat, $endtopcat , $endmidcat) {
    // Prepare the INSERT statement
    $insertQuery = "INSERT INTO endcats (endcat, endtopcat, endmidcat) VALUES (?,?,?)";

    if ($stmt = $conn->prepare($insertQuery)) {
        // Bind parameters and execute the query
        $stmt->bind_param("sss",  $endcat , $endtopcat , $endmidcat);
        if ($stmt->execute()) {
            echo "Data inserted successfully.";
        } else {
            echo "Error inserting data: " . $stmt->error;
        }
        $stmt->close();
        header("Location: ".$_SERVER['PHP_SELF']); // Refresh the page
        exit;
    } else {
        echo "Error preparing statement: " . $conn->error;
    }
}

// Check if the form is submitted
if (isset($_POST["submit"])) {
    $topcat = trim($_POST['topcat'] ?? '');
    $midcat = trim($_POST['midcat'] ?? '');
    $endcat = trim($_POST['endcat'] ?? '');
    $midtopcat = trim($_POST['midtopcat'] ?? '');
    $endtopcat = trim($_POST['endtopcat'] ?? '');
    $endmidcat = trim($_POST['endmidcat'] ?? '');


    // Validate inputs
    if (!empty($topcat)) {
        // Step 1: Ensure the table exists
        createTopCatsTable($conn);

        // Step 2: Insert data into the table
        insertTopCat($conn, $topcat);
    } else {
        echo "Both 'topcat'  fields are required.";
    }
   // Validate inputs
if (!empty($midcat) && !empty($midtopcat)) {
    // Step 1: Ensure the table exists
    createMidCatsTable($conn);

    // Step 2: Insert data into the table
    insertMidCat($conn, $midcat, $midtopcat);
} else {
    echo "Both 'midcat' and 'midtopcat' fields are required.";
}

    // Validate inputs
    if (!empty($endcat) && !empty($endtopcat) && !empty($endmidcat)) {
        // Step 1: Ensure the table exists
        createEndCatsTable($conn);

        // Step 2: Insert data into the table
        insertEndCat($conn, $endcat,$endtopcat , $endmidcat);
    } else {
        echo "Both 'midcat'  fields are required.";
    }







}

createTopCatsTable($conn);
createMidCatsTable($conn);
createEndCatsTable($conn);


function fetchTopCats($conn) {
    $fetchQuery = "SELECT * FROM topcats ORDER BY created_at ASC"; // Fetch all rows ordered by the newest
    $result = $conn->query($fetchQuery);

    if ($result) {
        if ($result->num_rows > 0) {
            $data = [];
            while ($row = $result->fetch_assoc()) {
                $data[] = $row; // Add each row to the data array
            }
            return $data; // Return the fetched data
        } else {
            echo "No data found in the 'topcats' table.";
            return [];
        }
    } else {
        die("Error fetching data: " . $conn->error);
    }
}
function fetchMidCats($conn) {
    $fetchQuery = "SELECT * FROM midcats ORDER BY created_at ASC"; // Fetch all rows ordered by the newest
    $result = $conn->query($fetchQuery);

    if ($result) {
        if ($result->num_rows > 0) {
            $data = [];
            while ($row = $result->fetch_assoc()) {
                $data[] = $row; // Add each row to the data array
            }
            return $data; // Return the fetched data
        } else {
            echo "No data found in the 'midcats' table.";
            return [];
        }
    } else {
        die("Error fetching data: " . $conn->error);
    }
}
function fetchEndCats($conn) {
    $fetchQuery = "SELECT * FROM endcats ORDER BY created_at ASC"; // Fetch all rows ordered by the newest
    $result = $conn->query($fetchQuery);

    if ($result) {
        if ($result->num_rows > 0) {
            $data = [];
            while ($row = $result->fetch_assoc()) {
                $data[] = $row; // Add each row to the data array
            }
            return $data; // Return the fetched data
        } else {
            echo "No data found in the 'midcats' table.";
            return [];
        }
    } else {
        die("Error fetching data: " . $conn->error);
    }
}

$topCats = fetchTopCats($conn);
$midCats = fetchMidCats($conn);
$endCats = fetchEndCats($conn);





// Handle Edit Request
$edit_id = null;
$edit_topcat = "";
if (isset($_GET['edit_id'])) {
    $edit_id = $_GET['edit_id'];
    // Fetch the existing record
    $query = "SELECT topcat FROM topcats WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $edit_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $edit_topcat = $row['topcat'];
    }
    $stmt->close();
}


// Handle Update Request
if (isset($_POST['update'])) {
    $topcat = trim($_POST['topcat']);
    $id = $_POST['id'];

    if (!empty($topcat) && !empty($id)) {
        $updateQuery = "UPDATE topcats SET topcat = ? WHERE id = ?";
        $stmt = $conn->prepare($updateQuery);
        $stmt->bind_param("si", $topcat, $id);
        if ($stmt->execute()) {
            echo "Category updated successfully.";
        } else {
            echo "Failed to update category.";
        }
        $stmt->close();
        header("Location: ".$_SERVER['PHP_SELF']); // Refresh the page
        exit;
    }
}






// Handle Edit Request
$edit_midid = null;
$edit_midcat = "";
$edit_midtopcat = "";

if (isset($_GET['edit_midid'])) {
    $edit_midid = $_GET['edit_midid'];
    // Fetch the existing record
    $query = "SELECT midtopcat, midcat FROM midcats WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $edit_midid);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $edit_midtopcat = $row['midtopcat'];
        $edit_midcat = $row['midcat'];
    }
    $stmt->close();
}

// Handle Update Request
if (isset($_POST['update'])) {
    $midtopcat = trim($_POST['midtopcat']);
    $midcat = trim($_POST['midcat']);
    $id = $_POST['id'];

    if (!empty($midtopcat) && !empty($midcat) && !empty($id)) {
        $updateQuery = "UPDATE midcats SET midtopcat = ?, midcat = ? WHERE id = ?";
        $stmt = $conn->prepare($updateQuery);
        $stmt->bind_param("ssi", $midtopcat, $midcat, $id);
        if ($stmt->execute()) {
            echo "Mid Category updated successfully.";
        } else {
            echo "Failed to update Mid Category.";
        }
        $stmt->close();
        header("Location: " . $_SERVER['PHP_SELF']); // Refresh the page
        exit;
    }
}




// Handle Edit Request
$edit_endid = null;
$edit_endtopcat = "";
$edit_endmidcat = "";
$edit_endcat = "";

if (isset($_GET['edit_endid'])) {
    $edit_endid = $_GET['edit_endid'];
    // Fetch the existing record
    $query = "SELECT endtopcat, endmidcat, endcat FROM endcats WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $edit_endid);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $edit_endtopcat = $row['endtopcat'];
        $edit_endmidcat = $row['endmidcat'];
        $edit_endcat = $row['endcat'];
    }
    $stmt->close();
}

// Handle Update Request
if (isset($_POST['update'])) {
    $endtopcat = trim($_POST['endtopcat']);
    $endmidcat = trim($_POST['endmidcat']);
    $endcat = trim($_POST['endcat']);
    $id = $_POST['id'];

    if (!empty($endtopcat) && !empty($endmidcat) && !empty($endcat)) {
        $updateQuery = "UPDATE endcats SET endtopcat = ?, endmidcat = ?, endcat = ? WHERE id = ?";
        $stmt = $conn->prepare($updateQuery);
        $stmt->bind_param("sssi", $endtopcat, $endmidcat, $endcat, $id);
        if ($stmt->execute()) {
            echo "End Category updated successfully.";
        } else {
            echo "Failed to update End Category.";
        }
        $stmt->close();
        header("Location: " . $_SERVER['PHP_SELF']); // Refresh the page
        exit;
    }
}





// Close the database connection
$conn->close();

?>



<?php include(__DIR__ . '/../../views/layouts/admin/header.php');?>
    <div class="container">
        <!-- Sidebar -->
        <?php include(__DIR__ . '/../../views/layouts/admin/sidebar.php'); ?>

        <!-- Main Content -->
        <main class="main-content">
            <h2>All Catagory</h2>
          
           
            <div class="top-cat-wrap">
                <h2>Top Catagory</h2>
           
                <div class="top-cat-display">
                   
                <table>
    <thead>
        <tr>
            <th>SL</th>
            <th>Top Category</th>
            <th>Created</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php
        if (!empty($topCats)) {
            foreach ($topCats as $cat) { ?>
                <tr>
                    <td><?php echo $cat['id']; ?></td>
                    <td><?php echo $cat['topcat']; ?></td>
                    <td><?php echo $cat['created_at']; ?></td>
                    <td>
                        <!-- Add action buttons/links here -->
                        <a href="?edit_id=<?php echo $cat['id']; ?>">Edit</a> 
                        
                    </td>
                </tr>
        <?php 
            } 
        } else { ?>
            <tr>
                <td colspan="4">No records found.</td>
            </tr>
        <?php } ?>
    </tbody>
</table>


                </div>
                <div class="top-cat-input">
               
    <form method="POST" action="">
        
        <label><?php echo $edit_id ? "Edit Top Category" : "Add Top Category"; ?></label>
        <input type="text" name="topcat" value="<?php echo htmlspecialchars($edit_topcat); ?>" required>
        <?php if ($edit_id): ?>
            <input type="hidden" name="id" value="<?php echo $edit_id; ?>">
            <button type="submit" name="update">Update Category</button>
        <?php else: ?>
            <button type="submit" name="submit">Add Category</button>
        <?php endif; ?>
    </form>

                </div>

            </div>
          
            <div class="top-cat-wrap">
           <h2>Mid Catagory</h2>
                <div class="top-cat-display">
                <table>
    <thead>
        <tr>
            <th>SL</th>
            <th>Top Category</th>
            <th>Mid Category</th>
            <th>Created</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php
        if (!empty($midCats)) {
            foreach ($midCats as $cat) { ?>
                <tr>
                    <td><?php echo $cat['id']; ?></td>
                    <td><?php echo $cat['midtopcat']; ?></td>
                    <td><?php echo $cat['midcat']; ?></td>
                    <td><?php echo $cat['created_at']; ?></td>
                    <td>
                        <!-- Add action buttons/links here -->
                        <a href="?edit_midid=<?php echo $cat['id']; ?>">Edit</a>
                       
                    </td>
                </tr>
        <?php 
            } 
        } else { ?>
            <tr>
                <td colspan="4">No records found.</td>
            </tr>
        <?php } ?>
    </tbody>
</table>

                </div>
                <div class="top-cat-input">
                    <form method="POST" action="">
                    <label><?php echo $edit_midid ? "Edit Mid Category" : "Add Mid Category"; ?></label>
                        <select name="midtopcat">
                            <option>Select Top Catagory</option>
                            <?php
                            if(!empty ($topCats)){
                                foreach ($topCats as $cat) { ?>
                                <option value="<?php echo $cat['topcat']; ?>" 
                        <?php echo ($cat['topcat'] == $edit_midtopcat) ? 'selected' : ''; ?>>
                        <?php echo $cat['topcat']; ?>
                    </option>
                                    

                           <?php }}
                            ?>
                        </select>

                        <label> Mid Catagory </label>
                        <input type="text" name="midcat" value="<?php echo htmlspecialchars($edit_midcat); ?>" required>
        <?php if ($edit_midid): ?>
            <input type="hidden" name="id" value="<?php echo $edit_midid; ?>">
            <button type="submit" name="update">Update Category</button>
        <?php else: ?>
            <button type="submit" name="submit">Add Category</button>
        <?php endif; ?>

                    </form>

                </div>

            </div>
           
            <div class="top-cat-wrap">
                <h2>End Catagory</h2>
          
                <div class="top-cat-display">
                <table>
    <thead>
        <tr>
            <th>SL</th>
            <th>Top Category</th>
            <th>Mid Category</th>
            <th>End  Category</th>
            <th>Created</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php
        if (!empty($endCats)) {
            foreach ($endCats as $cat) { ?>
                <tr>
                    <td><?php echo $cat['id']; ?></td>
                    <td><?php echo $cat['endtopcat']; ?></td>
                    <td><?php echo $cat['endmidcat']; ?></td>
                    <td><?php echo $cat['endcat']; ?></td>
                    <td><?php echo $cat['created_at']; ?></td>
                    <td>
                        <!-- Add action buttons/links here -->
                        <a href="?edit_endid=<?php echo $cat['id']; ?>">Edit</a>
                    </td>
                </tr>
        <?php 
            } 
        } else { ?>
            <tr>
                <td colspan="6">No records found.</td>
            </tr>
        <?php } ?>
    </tbody>
</table>

                </div>
                <div class="top-cat-input">

                <form method="POST" action="">
    <label><?php echo $edit_endid ? "Edit End Category" : "Add End Category"; ?></label>
    
    <select name="endtopcat" id="endtopcat">
        <option value="">Select Top Category</option>
        <?php if (!empty($midCats)) { 
            $categoriesByTopCat = []; // Grouping categories by top category
            foreach ($midCats as $cat) {
                $categoriesByTopCat[$cat['midtopcat']][] = $cat['midcat']; // Group mid categories by top category
            }
            foreach ($categoriesByTopCat as $topCat => $subCats) { ?>
                <option value="<?php echo $topCat; ?>" <?php echo ($topCat == $edit_endtopcat) ? 'selected' : ''; ?>><?php echo $topCat; ?></option>
            <?php }} ?>
    </select>

    <label>Mid Category</label>
<select name="endmidcat" id="endmidcat">
    <option value="">Select Mid Category</option>
    <!-- Mid Categories will be populated based on the Top Category selection -->
</select>

<script>
// This will store the options for mid categories, grouped by top category
var categoriesByTopCat = <?php echo json_encode($categoriesByTopCat); ?>;
var selectedMidCat = <?php echo json_encode($edit_endmidcat); ?>;  // Add the previously selected mid category (from the backend)

function populateMidCategories() {
    var topCatValue = document.getElementById('endtopcat').value;
    var midCatSelect = document.getElementById('endmidcat');

    // Clear current options
    midCatSelect.innerHTML = '<option value="">Select Mid Category</option>';

    // If a top category is selected, populate mid categories
    if (topCatValue && categoriesByTopCat[topCatValue]) {
        categoriesByTopCat[topCatValue].forEach(function(midCat) {
            var option = document.createElement('option');
            option.value = midCat;
            option.textContent = midCat;

            // If this midCat is the selected one, set it as selected
            if (midCat === selectedMidCat) {
                option.selected = true;
            }

            midCatSelect.appendChild(option);
        });
    }
}

// When the top category changes, update the mid category options
document.getElementById('endtopcat').addEventListener('change', populateMidCategories);

// Call populateMidCategories when the page loads to set initial values
window.addEventListener('load', populateMidCategories);
</script>
                      <label> End Catagory </label>
                        <input type="text" name="endcat" value="<?php echo htmlspecialchars($edit_endcat); ?>" required>

                        <?php if ($edit_endid): ?>
            <input type="hidden" name="id" value="<?php echo $edit_endid; ?>">
            <button type="submit" name="update">Update Category</button>
        <?php else: ?>
            <button type="submit" name="submit">Add Category</button>
        <?php endif; ?>

                    </form>

                </div>

            </div>


            <?php include(__DIR__ . '/../../views/layouts/admin/fotter.php'); ?>
        </div>


        </main>
    </div>



 <!-- fotter -->

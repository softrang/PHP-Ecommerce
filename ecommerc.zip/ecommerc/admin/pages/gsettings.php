
<?php

// Include database configuration
include_once __DIR__ . '/../config/database.php';

// Load environment variables
$env = parse_ini_file(__DIR__.'/../config/.env');

// Fetch variables from the .env file
$host = $env['DB_HOST'];
$username = $env['DB_USERNAME'];
$password = $env['DB_PASSWORD'];
$dbname = $env['DB_DATABASE'];
$port = $env['DB_PORT'];

// Database connection
$conn = new mysqli($host, $username, $password, $dbname, $port);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to create the table if it doesn't exist
function createSizeTable($conn) {
    // Create the table if it doesn't exist
    $createTableQuery = "CREATE TABLE IF NOT EXISTS sizes (
        id INT AUTO_INCREMENT PRIMARY KEY,
        size_name VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )";

    if (!$conn->query($createTableQuery)) {
        die("Error creating table: " . $conn->error);
    }
}
function createColorTable($conn) {
    // Create the table if it doesn't exist
    $createTableQuery = "CREATE TABLE IF NOT EXISTS colors (
        id INT AUTO_INCREMENT PRIMARY KEY,
        
        color_name VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )";

    if (!$conn->query($createTableQuery)) {
        die("Error creating table: " . $conn->error);
    }
}
function createBrandTable($conn) {
    // Create the table if it doesn't exist
    $createTableQuery = "CREATE TABLE IF NOT EXISTS brands (
        id INT AUTO_INCREMENT PRIMARY KEY,
        brand_name VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )";

    if (!$conn->query($createTableQuery)) {
        die("Error creating table: " . $conn->error);
    }
}

createSizeTable($conn);
createBrandTable($conn);
createColorTable($conn);


// Function to insert data into the topcats table
function insertSize($conn, $size) {
    // Prepare the INSERT statement
    $insertQuery = "INSERT INTO sizes (size_name) VALUES (?)";

    if ($stmt = $conn->prepare($insertQuery)) {
        // Bind parameters and execute the query
        $stmt->bind_param("s",  $size);
        if ($stmt->execute()) {
            echo "Data inserted successfully.";
        } else {
            echo "Error inserting data: " . $stmt->error;
        }
        $stmt->close();
            header("Location: ".$_SERVER['PHP_SELF']); // Refresh the page
        exit;
    } else {
        echo "Error preparing statement: " . $conn->error;
    }
}
function insertColor($conn, $color) {
    // Prepare the INSERT statement
    $insertQuery = "INSERT INTO colors (color_name) VALUES (?)";

    if ($stmt = $conn->prepare($insertQuery)) {
        // Bind parameters and execute the query
        $stmt->bind_param("s",  $color);
        if ($stmt->execute()) {
            echo "Data inserted successfully.";
        } else {
            echo "Error inserting data: " . $stmt->error;
        }
        $stmt->close();
        header("Location: ".$_SERVER['PHP_SELF']); // Refresh the page
        exit;
    } else {
        echo "Error preparing statement: " . $conn->error;
    }
}
function insertBrand($conn, $brand) {
    // Prepare the INSERT statement
    $insertQuery = "INSERT INTO brands (brand_name) VALUES (?)";

    if ($stmt = $conn->prepare($insertQuery)) {
        // Bind parameters and execute the query
        $stmt->bind_param("s",  $brand );
        if ($stmt->execute()) {
            echo "Data inserted successfully.";
        } else {
            echo "Error inserting data: " . $stmt->error;
        }
        $stmt->close();
        header("Location: ".$_SERVER['PHP_SELF']); // Refresh the page
        exit;
    } else {
        echo "Error preparing statement: " . $conn->error;
    }
}


// Check if the form is submitted
if (isset($_POST["submit_size"])) {
    $size = trim($_POST['size'] ?? '');
   

    // Validate inputs
    if (!empty($size)) {
        // Step 1: Ensure the table exists
        createSizeTable($conn);

        // Step 2: Insert data into the table
        insertSize($conn, $size);
    } else {
        echo "Both 'Size'  fields are required.";
    }


}
// Check if the form is submitted
if (isset($_POST["submit_color"])) {
    $color = trim($_POST['color'] ?? '');
   


   // Validate inputs
if (!empty($color)) {
    // Step 1: Ensure the table exists
    createColorTable($conn);

    // Step 2: Insert data into the table
    insertColor($conn, $color);
} else {
    echo " 'Color' fields are required.";
}

   

}
// Check if the form is submitted
if (isset($_POST["submit_brand"])) {
   
    $brand = trim($_POST['brand'] ?? '');


    
    // Validate inputs
    if (!empty($brand)) {
        // Step 1: Ensure the table exists
        createBrandTable($conn);

        // Step 2: Insert data into the table
        insertBrand($conn, $brand);
    } else {
        echo "Brand'  fields are required.";
    }


}


function fetchSize($conn) {
    $fetchQuery = "SELECT * FROM sizes ORDER BY created_at ASC"; // Fetch all rows ordered by the newest
    $result = $conn->query($fetchQuery);

    if ($result) {
        if ($result->num_rows > 0) {
            $data = [];
            while ($row = $result->fetch_assoc()) {
                $data[] = $row; // Add each row to the data array
            }
            return $data; // Return the fetched data
        } else {
            echo "No data found in the 'Sizes' table.";
            
            return [];
        }
    } else {
        die("Error fetching data: " . $conn->error);
    }
}
function fetchColor($conn) {
    $fetchQuery = "SELECT * FROM colors ORDER BY created_at ASC"; // Fetch all rows ordered by the newest
    $result = $conn->query($fetchQuery);

    if ($result) {
        if ($result->num_rows > 0) {
            $data = [];
            while ($row = $result->fetch_assoc()) {
                $data[] = $row; // Add each row to the data array
            }
            return $data; // Return the fetched data
        } else {
            echo "No data found in the 'Colors' table.";
            return [];
        }
    } else {
        die("Error fetching data: " . $conn->error);
    }
}
function fetchBrand($conn) {
    $fetchQuery = "SELECT * FROM brands ORDER BY created_at ASC"; // Fetch all rows ordered by the newest
    $result = $conn->query($fetchQuery);

    if ($result) {
        if ($result->num_rows > 0) {
            $data = [];
            while ($row = $result->fetch_assoc()) {
                $data[] = $row; // Add each row to the data array
            }
            return $data; // Return the fetched data
        } else {
            echo "No data found in the 'Brand' table.";
            return [];
        }
    } else {
        die("Error fetching data: " . $conn->error);
    }
}

$sizes = fetchSize($conn);
$brands = fetchBrand($conn);
$colors = fetchColor($conn);


// Handle Edit Request
$size_edit_id = null;
$edit_size = "";
if (isset($_GET['size_edit_id'])) {
    $size_edit_id = $_GET['size_edit_id'];
    // Fetch the existing record
    $query = "SELECT size_name FROM sizes WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $size_edit_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $edit_size = $row['size_name'];
    }
    $stmt->close();
}


// Handle Update Request
if (isset($_POST['update'])) {
    $size = trim($_POST['size']);
    $id = $_POST['id'];

    if (!empty($size) && !empty($id)) {
        $updateQuery = "UPDATE sizes SET size_name = ? WHERE id = ?";
        $stmt = $conn->prepare($updateQuery);
        $stmt->bind_param("si", $size, $id);
        if ($stmt->execute()) {
            echo "size updated successfully.";
        } else {
            echo "Failed to update category.";
        }
        $stmt->close();
        header("Location: ".$_SERVER['PHP_SELF']); // Refresh the page
        exit;
    }
}
// Handle Edit Request
$color_edit_id = null;
$edit_color = "";
if (isset($_GET['color_edit_id'])) {
    $color_edit_id = $_GET['color_edit_id'];
    // Fetch the existing record
    $query = "SELECT color_name FROM colors WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $color_edit_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $edit_color= $row['color_name'];
    }
    $stmt->close();
}


// Handle Update Request
if (isset($_POST['update'])) {
    $color = trim($_POST['color']);
    $id = $_POST['id'];

    if (!empty($color) && !empty($id)) {
        $updateQuery = "UPDATE colors SET color_name = ? WHERE id = ?";
        $stmt = $conn->prepare($updateQuery);
        $stmt->bind_param("si", $color, $id);
        if ($stmt->execute()) {
            echo "color updated successfully.";
        } else {
            echo "Failed to update category.";
        }
        $stmt->close();
        header("Location: ".$_SERVER['PHP_SELF']); // Refresh the page
        exit;
    }
}
// Handle Edit Request
$brand_edit_id = null;
$edit_brand = "";
if (isset($_GET['brand_edit_id'])) {
    $brand_edit_id = $_GET['brand_edit_id'];
    // Fetch the existing record
    $query = "SELECT brand_name FROM brands WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $brand_edit_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $edit_brand = $row['brand_name'];
    }
    $stmt->close();
}


// Handle Update Request
if (isset($_POST['update'])) {
    $brand = trim($_POST['brand']);
    $id = $_POST['id'];

    if (!empty($brand) && !empty($id)) {
        $updateQuery = "UPDATE brands SET brand_name = ? WHERE id = ?";
        $stmt = $conn->prepare($updateQuery);
        $stmt->bind_param("si", $brand, $id);
        if ($stmt->execute()) {
            echo "brand updated successfully.";
        } else {
            echo "Failed to update category.";
        }
        $stmt->close();
        header("Location: ".$_SERVER['PHP_SELF']); // Refresh the page
        exit;
    }
}


// Check if delete request is made
if (isset($_GET['color_delit_id'])) {
    $id = intval($_GET['color_delit_id']); // Sanitize the ID to prevent SQL injection

    // Prepare the delete query
    $query = "DELETE FROM colors WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $id);

    // Execute and check if successful
    if ($stmt->execute()) {
        echo "<script>alert('Record deleted successfully!');</script>";
        header("Location: ".$_SERVER['PHP_SELF']); // Refresh the page
        
    } else {
        echo "<script>alert('Failed to delete record. Please try again.');</script>";
    }

    $stmt->close();
}

if (isset($_GET['size_delit_id'])) {
    $id = intval($_GET['size_delit_id']); // Sanitize the ID to prevent SQL injection

    // Prepare the delete query
    $query = "DELETE FROM sizes WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $id);

    // Execute and check if successful
    if ($stmt->execute()) {
        echo "<script>alert('Record deleted successfully!');</script>";
        header("Location: ".$_SERVER['PHP_SELF']); // Refresh the page
        
    } else {
        echo "<script>alert('Failed to delete record. Please try again.');</script>";
    }

    $stmt->close();
}

if (isset($_GET['brand_delit_id'])) {
    $id = intval($_GET['brand_delit_id']); // Sanitize the ID to prevent SQL injection

    // Prepare the delete query
    $query = "DELETE FROM brands WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $id);

    // Execute and check if successful
    if ($stmt->execute()) {
        echo "<script>alert('Record deleted successfully!');</script>";
       
        
        header("Location: ".$_SERVER['PHP_SELF']); // Refresh the page
        
    } else {
        echo "<script>alert('Failed to delete record. Please try again.');</script>";
    }

    $stmt->close();
}





?>









<?php include(__DIR__ . '/../../views/layouts/admin/header.php');?>
    <div class="container">
        <!-- Sidebar -->
        <?php include(__DIR__ . '/../../views/layouts/admin/sidebar.php'); ?>

        <!-- Main Content -->
        <main class="main-content">

          <div class="scb-wrap">
            <h2>All Size </h2>
            <div class="scb-display" >
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Size name</th>
                            <th>Created</th>
                            <th>Updated</th>
                            <th>action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
        if (!empty($sizes)) {
            foreach ($sizes as $size) { ?>
                <tr>
                    <td><?php echo $size['id']; ?></td>
                    <td><?php echo $size['size_name']; ?></td>
                    <td><?php echo $size['created_at']; ?></td>
                    <td><?php echo $size['updated_at']; ?></td>
                    <td>
                        <!-- Add action buttons/links here -->
                        <a href="?size_edit_id=<?php echo $size['id']; ?>">Edit</a> 
                        <a style="background-color: #ce2828 ;" href="?size_delit_id=<?php echo $size['id']; ?>">Delet</a> 
                        
                    </td>
                </tr>
        <?php 
            } 
        } else { ?>
            <tr>
                <td colspan="5">No records found.</td>
            </tr>
        <?php } ?>
                    </tbody>
                </table>

            </div>
            <div class="scb-input" >
            <form method="POST" action="">
        
        <label><?php echo $size_edit_id ? "Edit Size" : "Add Size"; ?></label>
        <input type="text" name="size" value="<?php echo htmlspecialchars($edit_size); ?>" required>
        <?php if ($size_edit_id): ?>
            <input type="hidden" name="id" value="<?php echo $size_edit_id; ?>">
            <button type="submit" name="update">Update</button>
        <?php else: ?>
            <button type="submit" name="submit_size">Add</button>
        <?php endif; ?>
    </form>

            </div>

          </div>





          
          <div class="scb-wrap">
            <h2>All color </h2>
            <div class="scb-display" >
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Color name</th>
                            <th>Created</th>
                            <th>Updated</th>
                            <th>action</th>
                        </tr>
                    </thead>
                    <tbody>
                   <?php if (!empty($colors)) {
            foreach ($colors as $color) { ?>
                <tr>
                    <td><?php echo $color['id']; ?></td>
                    <td><?php echo $color['color_name']; ?></td>
                    <td><?php echo $color['created_at']; ?></td>
                    <td><?php echo $color['updated_at']; ?></td>
                    <td>
                        <!-- Add action buttons/links here -->
                        <a href="?color_edit_id=<?php echo $color['id']; ?>">Edit</a> 
                        <a style="background-color: #ce2828 ;" href="?color_delit_id=<?php echo $color['id']; ?>">Delet</a> 
                        
                    </td>
                </tr>
        <?php 
            } 
        } else { ?>
            <tr>
                <td colspan="5">No records found.</td>
            </tr>
        <?php } ?>
                    </tbody>
                </table>

            </div>
            <div class="scb-input" >
            <form method="POST" action="">
        
        <label><?php echo $color_edit_id ? "Edit Color" : "Add color"; ?></label>
        <input type="text" name="color" value="<?php echo htmlspecialchars($edit_color); ?>" required>
        <?php if ($color_edit_id): ?>
            <input type="hidden" name="id" value="<?php echo $color_edit_id; ?>">
            <button type="submit" name="update">Update</button>
        <?php else: ?>
            <button type="submit" name="submit_color">Add</button>
        <?php endif; ?>
    </form>
            </div>

          </div>
          <div class="scb-wrap">
            <h2>All Brand </h2>
            <div class="scb-display" >
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Brand name</th>
                            <th>Created</th>
                            <th>Updated</th>
                            <th>action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if (!empty($brands)) {
            foreach ($brands as $brand) { ?>
                <tr>
                    <td><?php echo $brand['id']; ?></td>
                    <td><?php echo $brand['brand_name']; ?></td>
                    <td><?php echo $brand['created_at']; ?></td>
                    <td><?php echo $brand['updated_at']; ?></td>
                    <td>
                        <!-- Add action buttons/links here -->
                        <a href="?brand_edit_id=<?php echo $brand['id']; ?>">Edit</a> 
                        <a style="background-color: #ce2828 ;" href="?brand_delit_id=<?php echo $brand['id']; ?>">Delet</a> 
                        
                    </td>
                </tr>
        <?php 
            } 
        } else { ?>
            <tr>
                <td colspan="5">No records found.</td>
            </tr>
        <?php } ?>
                    </tbody>
                </table>

            </div>
            <div class="scb-input" >
            <form method="POST" action="">
        
        <label><?php echo $brand_edit_id ? "Edit Brand" : "Add Brand"; ?></label>
        <input type="text" name="brand" value="<?php echo htmlspecialchars($edit_brand); ?>" required>
        <?php if ($brand_edit_id): ?>
            <input type="hidden" name="id" value="<?php echo $brand_edit_id; ?>">
            <button type="submit" name="update">Update</button>
        <?php else: ?>
            <button type="submit" name="submit_brand">Add</button>
        <?php endif; ?>
    </form>
            </div>

        </div>
        <?php include(__DIR__ . '/../../views/layouts/admin/fotter.php'); ?>
          

            
        </main>

 <!-- fotter -->

 </div>
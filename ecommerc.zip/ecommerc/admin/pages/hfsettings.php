<?php
// Include database configuration
include_once __DIR__ . '/../config/database.php';
include_once __DIR__ . '/../../controllars/databasequery.php';

// Load environment variables
$env = parse_ini_file(__DIR__.'/../config/.env');

// Fetch variables from the .env file
$host = $env['DB_HOST'];
$username = $env['DB_USERNAME'];
$password = $env['DB_PASSWORD'];
$dbname = $env['DB_DATABASE'];
$port = $env['DB_PORT'];

// Database connection
$conn = new mysqli($host, $username, $password, $dbname, $port);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to create the table if it doesn't exist
function createHeaderFooterTable($conn) {
    $header_fotter = 'CREATE TABLE IF NOT EXISTS `header_fotter` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `d_name` VARCHAR(255) NOT NULL,
        `phone` VARCHAR(15) NOT NULL,
        `email` VARCHAR(255) NOT NULL,
        `address` TEXT NOT NULL,
        `nl_title` VARCHAR(255) NOT NULL,
        `nl_dic` TEXT NOT NULL,
        `support` VARCHAR(255) NOT NULL,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )';

    if (!$conn->query($header_fotter)) {
        die("Error creating table: " . $conn->error);
    }
}
// Function to create the table if it doesn't exist
function createSocialTable($conn) {
    $header_fotter = 'CREATE TABLE IF NOT EXISTS `social_link` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `facebook` VARCHAR(255) NOT NULL,
        `instagram` VARCHAR(255) NOT NULL,
        `linkedin` VARCHAR(255) NOT NULL,
        `twiter` VARCHAR(255) NOT NULL,
        
        `printerest` VARCHAR(255) NOT NULL,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )';

    if (!$conn->query($header_fotter)) {
        die("Error creating table: " . $conn->error);
    }
}

// Call the function to create the table once
createHeaderFooterTable($conn);
createSocialTable($conn);

// Function to save form data
if (isset($_POST["submit"])) {
    // Validate inputs
    $dname = $_POST["dname"];
    $phone = $_POST["phone"];
    $email = $_POST["email"];
    $address = $_POST["address"];
    $nltitle = $_POST["nltitle"];
    $nldic = $_POST["nldic"];
    $support = $_POST["support"];

    // Prepare the SQL statement to insert the data
    $stmt = $conn->prepare("INSERT INTO header_fotter (d_name, phone, email, address, nl_title, nl_dic, support) VALUES (?, ?, ?, ?, ?, ?, ?)");

    if ($stmt === false) {
        die("Prepare failed: " . $conn->error);
    }

    // Bind parameters
    $stmt->bind_param(
        "sssssss",
        $dname,
        $phone,
        $email,
        $address,
        $nltitle,
        $nldic,
        $support
    );

    // Execute the query and handle the result
    if ($stmt->execute()) {
        echo "Data saved successfully!";
        header("location: " .$_SERVER["PHP_SELF"]);
        
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close the statement
    $stmt->close();
}


// Function to save form data
if (isset($_POST["socialSubmit"])) {
    // Validate inputs
    $facebook = $_POST["facebook"];
    $instagram = $_POST["instagram"];
    $linkedin = $_POST["linkedin"];
    $twiter = $_POST["twiter"];
    $printerest = $_POST["printerest"];
  

    // Prepare the SQL statement to insert the data
    $stmt = $conn->prepare("INSERT INTO social_link (facebook, instagram, linkedin, twiter, printerest) VALUES ( ?, ?, ?, ?, ?)");

    if ($stmt === false) {
        die("Prepare failed: " . $conn->error);
    }

    // Bind parameters
    $stmt->bind_param(
        "sssss",
        $facebook,
        $instagram,
        $linkedin,
        $twiter,
        $printerest,
        
    );

    // Execute the query and handle the result
    if ($stmt->execute()) {
        echo "Data saved successfully!";
        header("location: " .$_SERVER["PHP_SELF"]);
        
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close the statement
    $stmt->close();
}

// Close the database connection
$HF = getTabile($conn, 'header_fotter');
$SL = getTabile($conn, 'social_Link');




// Edit Functionality
if (isset($_GET['id'])) {
    // Get the ID of the record to be edited
    $id = $_GET['id'];

    // Fetch the data based on the ID
    $result = $conn->query("SELECT * FROM header_fotter WHERE id = $id");
    $data = $result->fetch_assoc();

    if (!$data) {
        die("Record not found.");
    }
}
// Edit Functionality
if (isset($_GET['socialid'])) {
    // Get the ID of the record to be edited
    $id = $_GET['socialid'];

    // Fetch the data based on the ID
    $result = $conn->query("SELECT * FROM social_link WHERE id = $id");
    $data = $result->fetch_assoc();

    if (!$data) {
        die("Record not found.");
    }
}



// Update the record when the form is submitted
if (isset($_POST['update'])) {
    // Sanitize and get the form data
    $dname = $_POST["dname"];
    $phone = $_POST["phone"];
    $email = $_POST["email"];
    $address = $_POST["address"];
    $nltitle = $_POST["nltitle"];
    $nldic = $_POST["nldic"];
    $support = $_POST["support"];

    // Update query to save the edited data
    $stmt = $conn->prepare("UPDATE header_fotter SET d_name = ?, phone = ?, email = ?, address = ?, nl_title = ?, nl_dic = ?, support = ? WHERE id = ?");
    
    if ($stmt === false) {
        die("Prepare failed: " . $conn->error);
    }

    // Bind parameters and execute the update query
    $stmt->bind_param("sssssssi", $dname, $phone, $email, $address, $nltitle, $nldic, $support, $id);

    // Execute the query and check for success
    if ($stmt->execute()) {
        echo "Data updated successfully!";
        header("location: " .$_SERVER["PHP_SELF"]);
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close the statement
    $stmt->close();
}

// Update the record when the form is submitted
if (isset($_POST['socialUpdate'])) {
    $facebook = $_POST["facebook"];
    $instagram = $_POST["instagram"];
    $linkedin = $_POST["linkedin"];
    $twiter = $_POST["twiter"];
    $printerest = $_POST["printerest"];

    // Update query to save the edited data
    $stmt = $conn->prepare("UPDATE social_link SET facebook = ?, instagram = ?, linkedin = ?, twiter = ?, printerest = ?  WHERE id = ?");
    
    if ($stmt === false) {
        die("Prepare failed: " . $conn->error);
    }

    // Bind parameters and execute the update query
    $stmt->bind_param("sssssi", $facebook, $instagram, $linkedin, $twiter, $printerest, $id);

    // Execute the query and check for success
    if ($stmt->execute()) {
        echo "Data updated successfully!";
        header("location: " .$_SERVER["PHP_SELF"]);
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close the statement
    $stmt->close();
}



// Function to create the table if it doesn't exist
function createUseLinkTable($conn) {
    // Create the table if it doesn't exist
    $createTableQuery = "CREATE TABLE IF NOT EXISTS uselinks (
        id INT AUTO_INCREMENT PRIMARY KEY,
        use_link VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )";

    if (!$conn->query($createTableQuery)) {
        die("Error creating table: " . $conn->error);
    }
}

createUseLinkTable($conn);


// Function to insert data into the topcats table
function insertUseLink($conn, $uselink) {
    // Prepare the INSERT statement
    $insertQuery = "INSERT INTO uselinks (use_link) VALUES (?)";

    if ($stmt = $conn->prepare($insertQuery)) {
        // Bind parameters and execute the query
        $stmt->bind_param("s",  $uselink);
        if ($stmt->execute()) {
            echo "Data inserted successfully.";
        } else {
            echo "Error inserting data: " . $stmt->error;
        }
        $stmt->close();
            header("Location: ".$_SERVER['PHP_SELF']); // Refresh the page
        exit;
    } else {
        echo "Error preparing statement: " . $conn->error;
    }
}


// Check if the form is submitted
if (isset($_POST["submit_uselink"])) {
    $uselink = trim($_POST['uselink'] ?? '');
   

    // Validate inputs
    if (!empty($uselink)) {
        // Step 1: Ensure the table exists
        createUseLinkTable($conn);

        // Step 2: Insert data into the table
        insertUseLink($conn, $uselink);
    } else {
        echo "Both 'uselink'  fields are required.";
    }


}


function fetchUseLink($conn) {
    $fetchQuery = "SELECT * FROM uselinks ORDER BY created_at ASC"; // Fetch all rows ordered by the newest
    $result = $conn->query($fetchQuery);

    if ($result) {
        if ($result->num_rows > 0) {
            $data = [];
            while ($row = $result->fetch_assoc()) {
                $data[] = $row; // Add each row to the data array
            }
            return $data; // Return the fetched data
        } else {
            echo "No data found in the 'Sizes' table.";
            
            return [];
        }
    } else {
        die("Error fetching data: " . $conn->error);
    }
}



$UseLink = fetchUseLink($conn);

// Handle Edit Request
$use_edit_id = null;
$edit_use = "";
if (isset($_GET['use_edit_id'])) {
    $use_edit_id = $_GET['use_edit_id'];
    // Fetch the existing record
    $query = "SELECT use_link FROM uselinks WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $use_edit_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $edit_use = $row['use_link'];
    }
    $stmt->close();
}



// Handle Update Request
if (isset($_POST['useupdate'])) {
    $uselink = trim($_POST['uselink']);
    $id = $_POST['id'];

    if (!empty($uselink) && !empty($id)) {
        $updateQuery = "UPDATE uselinks SET use_link = ? WHERE id = ?";
        $stmt = $conn->prepare($updateQuery);
        $stmt->bind_param("si", $uselink, $id);
        if ($stmt->execute()) {
            echo "use updated successfully.";
        } else {
            echo "Failed to update category.";
        }
        $stmt->close();
        header("Location: ".$_SERVER['PHP_SELF']); // Refresh the page
        exit;
    }
}


if (isset($_GET['use_delit_id'])) {
    $id = intval($_GET['use_delit_id']); // Sanitize the ID to prevent SQL injection

    // Prepare the delete query
    $query = "DELETE FROM uselinks WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $id);

    // Execute and check if successful
    if ($stmt->execute()) {
        echo "<script>alert('Record deleted successfully!');</script>";
        header("Location: ".$_SERVER['PHP_SELF']); // Refresh the page
        
    } else {
        echo "<script>alert('Failed to delete record. Please try again.');</script>";
    }

    $stmt->close();
}



$conn->close();





?>










<?php include(__DIR__ . '/../../views/layouts/admin/header.php');?>
    <div class="container">
        <!-- Sidebar -->
        <?php include(__DIR__ . '/../../views/layouts/admin/sidebar.php'); ?>

        <!-- Main Content -->
        <main class="main-content">

        <div class="hfsettings-wrap">
<!--<button onclick="opensocial()" > Add Social Link </button>-->
        <div class="vertical-table">
            <?php if (!empty($SL)):?>
                <?php foreach($SL as $sl): ?>
        <div class="row">
            <div class="label">Facebook:</div>
            <div class="value"><?php  echo $sl["facebook"]?></div>
        </div>
        <div class="row">
            <div class="label">Instagram:</div>
            <div class="value"><?php echo $sl["instagram"] ?></div>
        </div>
        <div class="row">
            <div class="label">Linkedin:</div>
            <div class="value"> <?php echo $sl["linkedin"] ?></div>
        </div>
        <div class="row">
            <div class="label">Twiter:</div>
            <div class="value"> <?php echo $sl["twiter"]  ?></div>
        </div>
        <div class="row">
            <div class="label">printerest :</div>
            <div class="value"> <?php echo $sl["printerest"] ?></div>
        </div>
      
        <div class="row">
            
        <a href="?socialid=<?php echo $sl["id"]; ?>" class="value">Edit</a>

        </div>
        <?php endforeach;?>
        <?php endif;?>
    </div>







<div id="socialform" class="mode">
    <div class="model-conten">
        
        <form class="custom-form" method="POST" action="">
<!--<span class="close" id="closeBTN">&times;</span>-->
    <div class="form-row">
        <label for="domainName">facebook</label>
        <input type="text" id="domainName" name="facebook"value="<?php echo isset($data['facebook']) ? htmlspecialchars($data['facebook']) : ''; ?>"placeholder="Enter the Domain Name">
    </div>
    <div class="form-row">
        <label for="phoneNumber">Instagram</label>
        <input type="text" id="phoneNumber" name="instagram"value="<?php echo isset($data['instagram']) ? htmlspecialchars($data['instagram']) : ''; ?>"placeholder="Enter the Phone Number">
    </div>
    <div class="form-row">
        <label for="email">Twter</label>
        <input type="text" id="email" name="twiter"value="<?php echo isset($data['twiter']) ? htmlspecialchars($data['twiter']) : ''; ?>"placeholder="Enter the Email">
    </div>
    <div class="form-row">
        <label for="address">Linkedin</label>
        <input type="text" id="address" name="linkedin" value="<?php echo isset($data['linkedin']) ? htmlspecialchars($data['linkedin']) : ''; ?>" placeholder="Enter the Address">
    </div>
    <div class="form-row">
        <label for="newsletterTitle">printerest</label>
        <input type="text" id="newsletterTitle" name="printerest" value="<?php echo isset($data['printerest']) ? htmlspecialchars($data['printerest']) : ''; ?>" placeholder="Enter the Newsletter Title">
    </div>
    
       <div class="form-row">
        <?php if(isset($data["id"])):?>
        <button type="submit" name="socialUpdate" class="submit-button">Update</button>
        <?php else :?>
        <button type="submit" name="socialSubmit" class="submit-button">Submit</button>
        <?php endif;?>
    </div>
</form>
</div>
</div>

</div>


<div class="hfsettings-wrap">  
        <div class="vertical-table">
<!--<button onclick="openhfmodel()"> Add Form </button>-->
            <?php if (!empty($HF)):?>
                <?php foreach($HF as $hf): ?>
        <div class="row">
            <div class="label">Domain ame:</div>
            <div class="value"><?php  echo $hf["d_name"]?></div>
        </div>
        <div class="row">
            <div class="label">Email:</div>
            <div class="value"><?php echo $hf["email"] ?></div>
        </div>
        <div class="row">
            <div class="label">Phone:</div>
            <div class="value"> <?php echo $hf["phone"] ?></div>
        </div>
        <div class="row">
            <div class="label">Address:</div>
            <div class="value"> <?php echo $hf["address"]  ?></div>
        </div>
        <div class="row">
            <div class="label">News Latter Title :</div>
            <div class="value"> <?php echo $hf["nl_title"] ?></div>
        </div>
        <div class="row">
            <div class="label">News Latter Discription :</div>
            <div class="value"><?php echo $hf["nl_dic"] ?></div>
        </div>
        <div class="row">
            <div class="label">News Support Time :</div>
            <div class="value"><?php echo $hf["support"]?></div>
        </div>
        <div class="row">
            
        <a href="?id=<?php echo $hf["id"]; ?>" class="value">Edit</a>
       <!-- <button onclick="edithfform(<?php echo $hf['id']; ?>)"> Edit Data </button>-->

        </div>
        <?php endforeach;?>
        <?php endif;?>
    </div>



    <!--<form id="editform"  method="post" action="">
            <input type="text" name="id" id="gethf"/>
            <button type="submit" id="hiddensubmit" name="getdata"> Get Data</button>
         </form>-->
            



    <div id="hfform" class="mode">
    <div class="model-conten">

        <form class="custom-form" method="POST" action="">
       <!-- <span class="close" id="closeBTNhf">&times;</span>-->
    <div class="form-row">
        <label for="domainName">Domain Name</label>
        <input type="text" id="domainName" name="dname"value="<?php echo isset($data['d_name']) ? htmlspecialchars($data['d_name']) : ''; ?>"placeholder="Enter the Domain Name">
    </div>
    <div class="form-row">
        <label for="phoneNumber">Phone Number</label>
        <input type="text" id="phoneNumber" name="phone"value="<?php echo isset($data['phone']) ? htmlspecialchars($data['phone']) : ''; ?>"placeholder="Enter the Phone Number">
    </div>
    <div class="form-row">
        <label for="email">Email</label>
        <input type="text" id="email" name="email"value="<?php echo isset($data['email']) ? htmlspecialchars($data['email']) : ''; ?>"placeholder="Enter the Email">
    </div>
    <div class="form-row">
        <label for="address">Address</label>
        <input type="text" id="address" name="address" value="<?php echo isset($data['address']) ? htmlspecialchars($data['address']) : ''; ?>" placeholder="Enter the Address">
    </div>
    <div class="form-row">
        <label for="newsletterTitle">Newsletter Title</label>
        <input type="text" id="newsletterTitle" name="nltitle" value="<?php echo isset($data['nl_title']) ? htmlspecialchars($data['nl_title']) : ''; ?>" placeholder="Enter the Newsletter Title">
    </div>
    <div class="form-row">
        <label for="newsletterDescription">Newsletter Description</label>
        <input type="text" id="newsletterDescription" name="nldic" value="<?php echo isset($data['nl_dic']) ? htmlspecialchars($data['nl_dic']) : ''; ?>" placeholder="Enter the Newsletter Description">
    </div>
    <div class="form-row">
        <label for="supportTime">Support Time</label>
        <input type="text" id="supportTime" name="support" value="<?php echo isset($data['support']) ? htmlspecialchars($data['support']) : ''; ?>" placeholder="Enter the Support Time">
    </div>
       <div class="form-row">
        <?php if(isset($data["id"])):?>
        <button type="submit" name="update" class="submit-button">Update</button>
        <?php else :?>
        <button type="submit" name="submit" class="submit-button">Submit</button>
        <?php endif;?>
    </div>
</form>

</div>
</div>
</div>




<div class="scb-wrap">
            <h2>All Use Full Link </h2>
            <div class="scb-display" >
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Link name</th>
                            <th>Created</th>
                            <th>Updated</th>
                            <th>action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
        if (!empty($UseLink)) {
            foreach ($UseLink as $use) { ?>
                <tr>
                    <td><?php echo $use['id']; ?></td>
                    <td><?php echo $use['use_link']; ?></td>
                    <td><?php echo $use['created_at']; ?></td>
                    <td><?php echo $use['updated_at']; ?></td>
                    <td>
                        <!-- Add action buttons/links here -->
                        <a href="?use_edit_id=<?php echo $use['id']; ?>">Edit</a> 
                        <a style="background-color: #ce2828 ;" href="?use_delit_id=<?php echo $use['id']; ?>">Delet</a> 
                        
                    </td>
                </tr>
        <?php 
            } 
        } else { ?>
            <tr>
                <td colspan="5">No records found.</td>
            </tr>
        <?php } ?>
                    </tbody>
                </table>

            </div>
            <div class="scb-input" >
            <form method="POST" action="">
        
        <label><?php echo $use_edit_id ? "Edit link name" : "Add link name"; ?></label>
        <input type="text" name="uselink" value="<?php echo htmlspecialchars($edit_use); ?>" required>
        <?php if ($use_edit_id): ?>
            <input type="hidden" name="id" value="<?php echo $use_edit_id; ?>">
            <button type="submit" name="useupdate">Update</button>
        <?php else: ?>
            <button type="submit" name="submit_uselink">Add</button>
        <?php endif; ?>
    </form>

            </div>

          </div>








<script>
/*
function opensocial(){
    document.getElementById("socialform").style.display = "block"


}

function openhfmodel(){
    document.getElementById("hfform").style.display = "block"


}

function edithfform(id) {
    document.getElementById("hfform").style.display = "block";
    document.getElementById("gethf").value = id
    document.getElementById("hiddensubmit").click()
    
}



document.getElementById("closeBTN").addEventListener("click",()=>{

 document.getElementById("socialform").style.display = "none"

})
document.getElementById("closeBTNhf").addEventListener("click",()=>{

 document.getElementById("hfform").style.display = "none"

})
*/


</script>




            
            <?php include(__DIR__ . '/../../views/layouts/admin/fotter.php'); ?>
        </main>

 <!-- fotter -->

 </div>

 
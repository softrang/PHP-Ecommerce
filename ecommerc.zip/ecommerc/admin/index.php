<?php
// Start session
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Include config and controller
include_once('../config/database.php');
include_once('../controllers/AdminController.php');

// Check if admin is logged in
if (!isset($_SESSION['user-id'])) {
    header('Location: login.php');
    exit();
} else{

    header(' pages/dashboard.php');

}

// Load dashboard
?>

<div class="sidebar">
    <ul class="sidebar-menu">
        <li><a href="../../admin/pages/dashboard.php">Dashboard</a></li>
        <li><a href= <?php echo "../../admin/pages/products.php" ?>>Manage Products</a></li>
        <li><a href= <?php echo "../../admin/pages/catagorys.php" ?>>Manage  Catagorys</a></li>
        <li><a href= <?php echo "../../admin/pages/hfsettings.php" ?>>Header Fotter</a></li>
        <li><a href= <?php echo "../../admin/pages/sliders.php" ?>>Manage Sliders</a></li>
        <li><a href= <?php echo "../../admin/pages/gsettings.php" ?>>Generel Settings</a></li>

       <!-- <li><a href="/admin/pages/users.php">Users</a></li>
        <li><a href="/admin/pages/settings.php">Settings</a></li>
        <li><a href="/logout.php">Logout</a></li>-->
    </ul>
</div>
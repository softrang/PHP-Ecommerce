
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="<?php echo'../../assets/css/admin.css'; ?>">
    <link rel="stylesheet" href="<?php echo'../../assets/css/admin/slider.css'; ?>">
    <link rel="stylesheet" href="<?php echo'../../assets/css/admin/product.css'; ?>">
    <link rel="stylesheet" href="<?php echo'../../assets/css/admin/gsettings.css'; ?>">
    <link rel="stylesheet" href="<?php echo'../../assets/css/admin/hfsettings.css'; ?>">



</head>
<body>

<header class="header">
    <div class="branding">
        <h1>Daily Shop</h1>
    </div>
    <div class="user-info">
        <p>Welcome, Admin</p>
        <a href="../../admin/logout.php">Logout</a>
    </div>
</header>


<footer class="footer">
    <p>&copy; 2024 dailyshop. All rights reserved.</p>
</footer>


<script src="../../assets/js/admin.js"> </script>

</body>
</html>

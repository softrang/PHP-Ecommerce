<?php
include_once __DIR__ . '/../../../controllars/databasequery.php';

$HF = getTabile($conn, 'header_fotter');

$id = '';
$d_name = '';
$phone = '';
$email =  '';
$address = '';
$nl_title = '';
$nl_dic = '';
$support = '';

foreach ($HF as $hf) {
    $id = $hf['id'];
    $d_name = $hf['d_name'];
    $phone = $hf['phone'];
    $email = $hf['email'];
    $address = $hf['address'];
    $nl_title = $hf['nl_title'];
    $nl_dic = $hf['nl_dic'];
    $support = $hf['support'];
  

}


$SL = getTabile($conn, 'social_link');

$id = '';
$facebook = '';
$instagram = '';
$linkedin =  '';
$twiter = '';
$printerest = '';

foreach ($SL as $sl) {
    $id = $sl['id'];
    $facebook = $sl['facebook'];
    $instagram = $sl['instagram'];
    $linkedin = $sl['linkedin'];
    $twiter = $sl['twiter'];
    $printerest = $sl['printerest'];


}

$UL = getTabile($conn, 'uselinks');

?>









<!-- Footer Section Begin -->
<footer class="footer spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="footer__about">
                        <div class="footer__about__logo">
                            <a href="./index.html"><img src="img/logo.png" alt=""></a>
                        </div>
                        <ul>
                            <li>Address: <?php echo $address?></li>
                            <li>Phone: <?php echo $phone ?></li>
                            <li>Email: <?php echo $email?></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-5 col-md-6 col-sm-6 ">
                   
                                                
    <?php if (!empty($UL)): ?>
        <?php 
        // Split the $UL array into chunks of 4
        $chunks = array_chunk($UL, 5); 
        ?>
                    <div class="footer__widget">
                        <h6>Useful Links</h6>
                        
        <?php foreach ($chunks as $chunk): ?>
            <ul style=" list-style: none; padding: 0; margin: 0;">
                <?php foreach ($chunk as $ul): ?>
                    <li style="margin-right: 5px; width:max-content;"><a href="#"><?php echo $ul["use_link"]; ?></a></li>
                <?php endforeach; ?>
            </ul>
        <?php endforeach; ?>
    <?php endif; ?>
</div>


                        
                    
                </div>
                <div class="col-lg-4 col-md-12">
                    <div class="footer__widget">
                        <h6><?php  echo $nl_title?></h6>
                        <p><?php echo $nl_dic ?></p>
                        <form action="#">
                            <input type="text" placeholder="Enter your mail">
                            <button type="submit" class="site-btn">Subscribe</button>
                        </form>
                        <div class="footer__widget__social">
                            
                            <a href="<?php echo $facebook?>"><i class="fa fa-facebook"></i></a>
                            <a href="<?php echo $instagram?>"><i class="fa fa-instagram"></i></a>
                            <a href="<?php echo $linkedin?>"><i class="fa fa-linkedin"></i></a>
                            <a href="<?php echo $printerest?>"><i class="fa fa-pinterest-p"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="footer__copyright">
                        <div class="footer__copyright__text"><p>
  Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved <?php echo $d_name?> maide <i class="fa fa-heart" aria-hidden="true"></i> by <a href="https://rangcon.com" target="_blank">Rangcon</a>
  </p></div>
                        <div class="footer__copyright__payment"><img src="img/payment-item.png" alt=""></div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer Section End -->

    <!-- Js Plugins -->
    <script src="assets/frontend/js/jquery-3.3.1.min.js"></script>
    <script src="assets/frontend/js/bootstrap.min.js"></script>
    <script src="assets/frontend/js/jquery.nice-select.min.js"></script>
    <script src="assets/frontend/js/jquery-ui.min.js"></script>
    <script src="assets/frontend/js/jquery.slicknav.js"></script>
    <script src="assets/frontend/js/mixitup.min.js"></script>
    <script src="assets/frontend/js/owl.carousel.min.js"></script>
    <script src="assets/frontend/js/main.js"></script>









<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>

<script src="assets/js/main.js"></script>
</body>
</html>

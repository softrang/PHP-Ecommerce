<?php

global $conn;
// Load .env variables manually
$env = parse_ini_file(__DIR__.'/../../../../admin/config/.env');

// Fetch variables
$host = $env['DB_HOST'];
$username = $env['DB_USERNAME'];
$password = $env['DB_PASSWORD'];
$dbname = $env['DB_DATABASE'];
$port = $env['DB_PORT'];

$conn = new mysqli($host, $username, $password, $dbname, $port);

$data_query = "SELECT * FROM images";
$result = $conn->query($data_query);


?>




<div class="swiper mySwiper">
    <div class="swiper-wrapper">
        <?php

    //Check if the result is valid and has rows
if ($result && $result->num_rows > 0): 
    while ($row = $result->fetch_assoc()): ?>

<div class="swiper-slide">

    <img src="uploads/<?php  echo htmlspecialchars($row['image_name'], ENT_QUOTES, 'UTF-8'); ?>" alt="Image">

</div>

               
            

           
    <?php endwhile; 
else: ?>
    
        <h2 >No images found.</h2>
    
<?php endif; ?>


    </div>
    <div class="swiper-button-next"></div>
    <div class="swiper-button-prev"></div>
    <div class="swiper-pagination"></div>
  </div>

<?php
include_once __DIR__ . '/../../../../controllars/databasequery.php';

$products = getTabile($conn, 'products');
$topCats = getTabile($conn, 'topcats');
function getUniqueCategories($products, $key) {
    $unique = [];
    $result = [];

    foreach ($products as $product) {
        if (!in_array($product[$key], $unique)) {
            $unique[] = $product[$key];
            $result[] = $product;
        }
    }

    return $result;
}

?>



    <?php 
    /*
    $discountedProducts = array_filter($products, function ($products) {
        return isset($discount['p_is_lataset']) && $discount['p_is_lataset'] === "Yes";
    });
    $discountedProducts = array_filter($products, function ($products) {
        return isset($discount['p_is_lataset']) && $discount['p_is_lataset'] === "Yes";
    });
*/
?>






<!-- Featured Section Begin -->
<section class="featured spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title">
                        <h2>Featured Product</h2>
                    </div>
                
    
        <!-- Filter Buttons -->
        
            <div class="featured__controls">
            <ul class="d-flex justify-content-center">
    <!-- 'All' Option -->
    <li class="active" data-filter="*">All</li>



<ul class="d-flex justify-content-center">
    <?php if (!empty($products)): ?>
        <?php
        // Remove duplicate categories based on 't_cat'
        $uniqueProducts = getUniqueCategories($products, 't_cat');
        ?>
        <!-- Loop through unique categories -->
        <?php foreach ($uniqueProducts as $product): 
            
// Get the category and remove spaces and quotes
$cleanedCategory = str_replace([' ', "'", '"'], '', $product['t_cat']);


?>
            <li data-filter=.<?php echo htmlspecialchars($cleanedCategory); ?>>
                <?php echo htmlspecialchars($product['t_cat']); ?>
            </li>
        <?php endforeach; ?>
    <?php else: ?>
        <!-- Fallback if no categories available -->
        <div class="col-12">
            <p>No categories available.</p>
        </div>
    <?php endif; ?>
</ul>

</ul>

      

    <div class="row featured__filter mt-5">
        <!-- Loop through products -->
        <?php if (!empty($products)): ?>
            <?php foreach ($products as $product): 
                // Get the category and remove spaces and quotes
                $cleanedCategory = str_replace([' ', "'", '"'], '', $product['t_cat']); ?>

                <div class="col-lg-3 col-md-4 col-sm-6 mix <?php echo htmlspecialchars($cleanedCategory); ?> ">
                    <div class="featured__item">
                        <!-- Product Image -->
                        <div class="featured__item__pic set-bg" data-setbg="<?php echo htmlspecialchars("uploads/products/" . $product['thumb_image']); ?>">
                            <ul class="featured__item__pic__hover">
                                <li><a href="#"><i class="fa fa-heart"></i></a></li>
                                <li><a href="#"><i class="fa fa-retweet"></i></a></li>
                                <li><a href="#"><i class="fa fa-shopping-cart"></i></a></li>
                            </ul>
                        </div>
                        <!-- Product Details -->
                        <div class="featured__item__text text-center">
                            <h6><a href="#"><?php echo htmlspecialchars($product['p_title']); ?></a></h6>
                            <h5>$<?php echo number_format($product['p_price'], 2); ?></h5>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="col-12">
                <p>No products available.</p>
            </div>
        <?php endif; ?>














    </div>

</div>
            </div>
        </div>
    </section>
    <!-- Featured Section End -->

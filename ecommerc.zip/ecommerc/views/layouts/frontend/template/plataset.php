

<h1>latest products</h1>


<div dir="rtl" class="swiper mySwiperProduct">
    <div class="swiper-wrapper">
        <?php if (!empty($discounts)): ?>
            <?php 
            $discountedProducts = array_filter($discounts, function ($discount) {
                return isset($discount['p_is_lataset']) && $discount['p_is_lataset'] === "Yes";
            });

            if (!empty($discountedProducts)): ?>
                <?php foreach ($discountedProducts as $discount): ?>
                    <div class="swiper-slide product-card">
                        <div class="produc-card">
                            <img src="<?php echo htmlspecialchars("uploads/products/" . $discount['thumb_image']); ?>" alt="<?php echo htmlspecialchars($discount['p_title']); ?> Image">
                            <h3><?php echo htmlspecialchars($discount['p_title']); ?></h3>
                            <p>$<?php echo number_format($discount['p_price'], 2); ?></p>
                            <a href="product.php?id=<?php echo urlencode($discount['id']); ?>">View Details</a>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <!-- Fallback for no discounted products -->
                <div class="swiper-slide">
                    <p>No discounted products available.</p>
                </div>
            <?php endif; ?>
        <?php else: ?>
            <!-- Fallback for no products -->
            <div class="swiper-slide">
                <p>No products available.</p>
            </div>
        <?php endif; ?>
    </div>
    <div class="swiper-button-next"></div>
    <div class="swiper-button-prev"></div>
    <div class="swiper-pagination"></div>
</div>



        
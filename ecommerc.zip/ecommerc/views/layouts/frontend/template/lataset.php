
<?php
include_once __DIR__ . '/../../../../controllars/databasequery.php';

$discounts = getTabile($conn, 'products');
?>



<!-- Latest Product Section Begin -->
<section class="latest-product spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-6">
                    <div class="latest-product__text">
                        <h4>Latest Products</h4>
                        <div class="latest-product__slider owl-carousel">
                          


                            <?php if (!empty($discounts)): ?>
    <?php 
    $discountedProducts = array_filter($discounts, function ($discount) {
        return isset($discount['p_is_lataset']) && $discount['p_is_lataset'] === "Yes";
    });

    if (!empty($discountedProducts)): ?>
        <?php 
        $counter = 0; 
        foreach ($discountedProducts as $discount): 
            // যদি গ্রুপের শুরু হয়, একটি ডিভ ব্লক শুরু করুন
            if ($counter % 3 === 0): ?>
                <div class="latest-prdouct__slider__item">
            <?php endif; ?>

            <a href="product.php?id=<?php echo urlencode($discount['id']); ?>" class="latest-product__item">
                <div class="latest-product__item__pic">
                    <img src="<?php echo htmlspecialchars("uploads/products/" . $discount['thumb_image']); ?>" alt="">
                </div>
                <div class="latest-product__item__text">
                    <h6><?php echo htmlspecialchars($discount['p_title']); ?></h6>
                    <span>$<?php echo number_format($discount['p_price'], 2); ?></span>
                </div>
            </a>

            <?php 
            $counter++; 
            // যদি গ্রুপ শেষ হয়, ডিভ ব্লক বন্ধ করুন
            if ($counter % 3 === 0): ?>
                </div>
            <?php endif; ?>
        <?php endforeach; ?>

        <?php 
        // যদি লাস্ট গ্রুপ অসম্পূর্ণ থাকে, তবে ডিভ ব্লক বন্ধ করুন
        if ($counter % 3 !== 0): ?>
            </div>
        <?php endif; ?>
    <?php else: ?>
        <p>No discounted products available.</p>
    <?php endif; ?>
<?php else: ?>
    <p>No products available.</p>
<?php endif; ?>


                            
                            
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="latest-product__text">
                        <h4> Futuret Products</h4>
                        <div class="latest-product__slider owl-carousel">
                        <?php if (!empty($discounts)): ?>
    <?php 
    $discountedProducts = array_filter($discounts, function ($discount) {
        return isset($discount['p_is_future']) && $discount['p_is_future'] === "Yes";
    });

    if (!empty($discountedProducts)): ?>
        <?php 
        $counter = 0; 
        foreach ($discountedProducts as $discount): 
            // যদি গ্রুপের শুরু হয়, একটি ডিভ ব্লক শুরু করুন
            if ($counter % 3 === 0): ?>
                <div class="latest-prdouct__slider__item">
            <?php endif; ?>

            <a href="product.php?id=<?php echo urlencode($discount['id']); ?>" class="latest-product__item">
                <div class="latest-product__item__pic">
                    <img src="<?php echo htmlspecialchars("uploads/products/" . $discount['thumb_image']); ?>" alt="">
                </div>
                <div class="latest-product__item__text">
                    <h6><?php echo htmlspecialchars($discount['p_title']); ?></h6>
                    <span>$<?php echo number_format($discount['p_price'], 2); ?></span>
                </div>
            </a>

            <?php 
            $counter++; 
            // যদি গ্রুপ শেষ হয়, ডিভ ব্লক বন্ধ করুন
            if ($counter % 3 === 0): ?>
                </div>
            <?php endif; ?>
        <?php endforeach; ?>

        <?php 
        // যদি লাস্ট গ্রুপ অসম্পূর্ণ থাকে, তবে ডিভ ব্লক বন্ধ করুন
        if ($counter % 3 !== 0): ?>
            </div>
        <?php endif; ?>
    <?php else: ?>
        <p>No discounted products available.</p>
    <?php endif; ?>
<?php else: ?>
    <p>No products available.</p>
<?php endif; ?>


                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="latest-product__text">
                        <h4>Discount Products</h4>
                        <div class="latest-product__slider owl-carousel">
                        <?php if (!empty($discounts)): ?>
    <?php 
    $discountedProducts = array_filter($discounts, function ($discount) {
        return isset($discount['p_is_discount']) && $discount['p_is_discount'] === "Yes";
    });

    if (!empty($discountedProducts)): ?>
        <?php 
        $counter = 0; 
        foreach ($discountedProducts as $discount): 
            // যদি গ্রুপের শুরু হয়, একটি ডিভ ব্লক শুরু করুন
            if ($counter % 3 === 0): ?>
                <div class="latest-prdouct__slider__item">
            <?php endif; ?>

            <a href="product.php?id=<?php echo urlencode($discount['id']); ?>" class="latest-product__item">
                <div class="latest-product__item__pic">
                    <img src="<?php echo htmlspecialchars("uploads/products/" . $discount['thumb_image']); ?>" alt="">
                </div>
                <div class="latest-product__item__text">
                    <h6><?php echo htmlspecialchars($discount['p_title']); ?></h6>
                    <span>$<?php echo number_format($discount['p_price'], 2); ?></span>
                </div>
            </a>

            <?php 
            $counter++; 
            // যদি গ্রুপ শেষ হয়, ডিভ ব্লক বন্ধ করুন
            if ($counter % 3 === 0): ?>
                </div>
            <?php endif; ?>
        <?php endforeach; ?>

        <?php 
        // যদি লাস্ট গ্রুপ অসম্পূর্ণ থাকে, তবে ডিভ ব্লক বন্ধ করুন
        if ($counter % 3 !== 0): ?>
            </div>
        <?php endif; ?>
    <?php else: ?>
        <p>No discounted products available.</p>
    <?php endif; ?>
<?php else: ?>
    <p>No products available.</p>
<?php endif; ?>

                          
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Latest Product Section End -->

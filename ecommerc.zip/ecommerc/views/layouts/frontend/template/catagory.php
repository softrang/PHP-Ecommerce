   
   <?php
include_once __DIR__ . '/../../../../controllars/databasequery.php';

$topCats = getTabile($conn, 'topcats');

?>
   
   
   <!-- Categories Section Begin -->
    <section class="categories">
        <div class="container">
            <div class="row">
                <div class="categories__slider owl-carousel">
                    <?php if(!empty($topCats)): ?>
                        <?php foreach($topCats as $topcat):?>
                            <div class="col-lg-3">
                        <div class="categories__item set-bg" data-setbg="img/categories/cat-1.jpg">
                            <h5><a href="#"><?php echo $topcat["topcat"]?></a></h5>
                        </div>
                    </div>
                        <?php endforeach;?>
                        <?php endif?>


                                   </div>
            </div>
        </div>
    </section>
    <!-- Categories Section End -->
